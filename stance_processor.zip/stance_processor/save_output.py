def stance_vector_to_user_label(user_stance_vector, 
                                index_to_user_id, 
                                out_file_name,
                                results_path = './results/'):
    
    with open(results_path + out_file_name, 'w') as f_write:
        for i in range(0, len(user_stance_vector)):
            userId = index_to_user_id[i]
            stance = int(user_stance_vector[i][0])

            f_write.write("{},{}\n".format(userId,stance ))
                
        
def write_stance_output(item_stance_vector, 
                        item_stance_vector_conf,
                        user_item_count,
                        index_to_item_id, 
                        out_file_name,
                        first_column_name  = 'userId',
                        results_path = './results/'):
    
    item_users = {} 
    for user, item_count in user_item_count.items():
        
        if isinstance(item_count, int):
            item_users[user] = item_count
        else:
            for item, count in item_count.items():
                if item not in item_users:
                    item_users[item] = 0

                item_users[item] = item_users[item] + 1
    
    user_stance  = {}
    user_stance_conf = {}
    with open(results_path + out_file_name, 'w') as f_write:
        f_write.write("{},{},{},{}\n".format(first_column_name,'count', 'stance', 'confidence' ))
        for i in range(0, len(item_stance_vector)):
            itemId = index_to_item_id[i]
            count = item_users[itemId]
            stance = int(item_stance_vector[i][0])
            conf = item_stance_vector_conf[i][0] 

            user_stance[itemId] = stance
            user_stance_conf[itemId] = conf

            f_write.write("{},{},{},{:0.2f}\n".format(itemId,count, stance,conf))

    return user_stance, user_stance_conf

def read_stance_output( out_file_name, results_path = './results/'):
    # item_stance_vector, 
    #  item_stance_vector_conf,
    #  user_item_count,
    #  index_to_item_id, 
    
    property_name_stance = {}
    property_name_count = {}

    with open(results_path + out_file_name, 'r') as f_read:

        
        i = 0
        for line in f_read:
            if i > 0:
                parts = line.strip().split(',')
                if len(parts) == 4:
                    property_name, count, stance, confidence = parts

                    if property_name not in property_name_stance:
                        property_name_stance[property_name] = int(stance)
                    else:
                        print('Multiple peoprty name in the file')


                    if property_name not in property_name_count:
                        property_name_count[property_name] = int(count)
                    else:
                        print('Multiple peoprty name in the file')

            i += 1

    return property_name_stance, property_name_count      


#     user,url,count
# 45014353,http://pbs.twimg.com/media/EVfVBJLX0AM6LP4.jpg,1     # 

def read_media_stance_output( out_file_name, results_path = './results/'):
    # item_stance_vector, 
    #  item_stance_vector_conf,
    #  user_item_count,
    #  index_to_item_id, 
    
    property_name_stance = {}
    property_name_count = {}

    with open(results_path + out_file_name, 'r') as f_read:

        
        i = 0
        for line in f_read:
            if i > 0:
                parts = line.strip().split(',')
                if len(parts) == 3:
                    property_name, count, stance, confidence = parts

                    if property_name not in property_name_stance:
                        property_name_stance[property_name] = int(stance)
                    else:
                        print('Multiple peoprty name in the file')


                    if property_name not in property_name_count:
                        property_name_count[property_name] = int(count)
                    else:
                        print('Multiple peoprty name in the file')

            i += 1

    return property_name_stance, property_name_count      

