from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score
from numpy import random as rd
import random 
import numpy as np

class TextClassifier():

    def __init__(self, tweet_user_index, users_index_to_id, dataHandler):
        self.tweet_user_index = tweet_user_index
        self.users_index_to_id = users_index_to_id
        self.dataHandler = dataHandler
        
        
    def get_most_common_array_element(self, array):

        b = Counter(array)
        most_common =  b.most_common(1)[0][0]
        return most_common
    
    def get_most_common_array_element_with_confidence(self, array):

        array_witout_zero = []
        confidence = 0
        for num in array:
            if num != 0:
                array_witout_zero.append(num)

        if len(array_witout_zero)> 0:            
            b = Counter(array_witout_zero)
            most_common =  b.most_common(1)[0][0]
#             confidence = (b.most_common(1)[0][1]) /len(array_witout_zero) 
            confidence = (b.most_common(1)[0][1]) /(1 + len(array_witout_zero)) 
            # 1 is added to give low confidence to single example (this paprameter should be tested)

        else:
            most_common = 0
            confidence = 1.0

        return most_common, confidence

    def get_accuracy_estimate(self, truths, predicted):

        print(classification_report(truths, predicted))
        print(' TEXT Classifier Accuracy: ', accuracy_score(truths, predicted))
        
        return accuracy_score(truths, predicted)
        
        
    def train_model2(self, user_stance_matrix, 
                         text_clf_svm = Pipeline([('vect', CountVectorizer()),
                                 ('tfidf', TfidfTransformer()),
                                 ('clf-svm', SGDClassifier(loss='hinge', penalty='l2',
                                                           alpha=1e-3, max_iter=5, random_state=42)),
                                ]),
                         parameters_svm = {'vect__ngram_range': [(1, 1), (1, 2)], 
                              'tfidf__use_idf': (True, False),
                              'clf-svm__alpha': (1e-2, 1e-3),
                             }
                     
                    ):
        
        train_pro_texts, train_anti_texts = self.dataHandler.get_text_data_from_user_labels(
                                                user_stance_matrix, 
                                                self.users_index_to_id)

        print('Before balancing: ', len(train_pro_texts) , len(train_anti_texts))
        
        
        features = train_pro_texts + train_anti_texts
        labels = [1]*len(train_pro_texts) + [-1]*len(train_anti_texts)

        
        y_counts, y_Xs, y_indices = ClassBalancer.get_stance_stats(features, labels)
#         print('Before balancing: ',  len(y_counts), len(y_indices))
        features, labels, __ = ClassBalancer.balance_stance_classes(features, labels)
    
        print('Total after balancing: ', len(features), len(labels))
        
        text_clf_svm.fit(features,  labels)
        
        return text_clf_svm
    
    def train_model3(self, user_stance_matrix, 
                         text_clf_svm = Pipeline([('vect', CountVectorizer()),
                                 ('tfidf', TfidfTransformer()),
                                 ('clf-svm', SGDClassifier(loss='hinge', penalty='l2',
                                                           alpha=1e-3, max_iter=5, random_state=42)),
                                ]),
                         parameters_svm = {'vect__ngram_range': [(1, 1), (1, 2)], 
                              'tfidf__use_idf': (True, False),
                              'clf-svm__alpha': (1e-2, 1e-3),
                             },
                     additional_features = [],
                     additional_labels = []
                     
                    ):
        
        train_pro_texts, train_anti_texts = self.dataHandler.get_text_data_from_user_labels(
                                                user_stance_matrix, 
                                                self.users_index_to_id)

        print('Before balancing: ', len(train_pro_texts) , len(train_anti_texts))
        
        
        features = train_pro_texts + train_anti_texts
        labels = [1]*len(train_pro_texts) + [-1]*len(train_anti_texts)

        
        y_counts, y_Xs, y_indices = ClassBalancer.get_stance_stats(features, labels)
#         print('Before balancing: ',  len(y_counts), len(y_indices))
        features, labels, __ = ClassBalancer.balance_stance_classes(features, labels)
    
        print('Total after balancing: ', len(features), len(labels))
        
        text_clf_svm.fit(features + additional_features,  labels+ additional_labels)
        
        return text_clf_svm
    
            
    def predict(self, text_clf_svm, users_text, tweet_user_index):
        
        user_stance_predictions = {}
        for user, texts in users_text.items():
            user_index = tweet_user_index[user]
            predicted_texts_stance = text_clf_svm.predict(texts)
            for text_stance in predicted_texts_stance:
                if user not in user_stance_predictions:
                    user_stance_predictions[user] = [text_stance]
                else:
                    user_stance_predictions[user].append(text_stance)
                    
        final_user_predictions = {}
        for user, predictions in user_stance_predictions.items():
            most_common_stance = self.get_most_common_array_element(predictions)
            final_user_predictions[user] = most_common_stance

        predicted_user_stance_matrix = np.zeros((len(tweet_user_index), 1))
        for user_id, prediction in user_stance_predictions.items():
            user_index = tweet_user_index[user_id]
            predicted_user_stance_matrix[user_index] = self.get_most_common_array_element(prediction)
            
        return final_user_predictions, predicted_user_stance_matrix 

            
    def check_models_performance2(self, text_clf_svm, user_label):

        if hasattr(self, 'test_pro_tweets'):
            print('test data exists')
        else:
            test_pro_tweets, test_anti_tweets,  pro_user_ids, anti_user_ids = self.dataHandler.get_test_text_data(user_label)
            self.test_pro_tweets = test_pro_tweets
            self.test_anti_tweets = test_anti_tweets
            self.pro_user_ids = pro_user_ids
            self.anti_user_ids = anti_user_ids
    
            
                    
        predicted = text_clf_svm.predict(self.test_pro_tweets + self.test_anti_tweets)
        truth = [1]*len(self.test_pro_tweets) + [-1]*len(self.test_anti_tweets)
        user_ids = self.pro_user_ids + self.anti_user_ids

        user_predcitions = {}
        user_truths = {}
        for user_id, predict, true in zip(user_ids, predicted, truth):
            if user_id not in user_predcitions:
                user_predcitions[user_id] = []

            if user_id not in user_truths:
                user_truths[user_id] = []

            user_predcitions[user_id].append(predict)
            user_truths[user_id].append(true)        

        final_user_predictions = []
        final_user_truths = []
        for user, predictions in user_predcitions.items():
            most_common_stance = self.get_most_common_array_element(predictions)
            final_user_predictions.append(most_common_stance)
            
            most_common_truth = self.get_most_common_array_element(user_truths[user])
            final_user_truths.append(most_common_truth)
            
            
#         users_text = self.dataHandler.get_users_text()
        
#         __, predicted_user_stance_matrix  = self.predict(text_clf_svm, users_text, self.tweet_user_index)            
            
        return self.get_accuracy_estimate(final_user_truths, final_user_predictions)
        
        
    def update_users_using_text_classifier(self, text_clf_svm, 
                                           user_stance_matrix):
        
        users_text = self.dataHandler.get_users_text()
        proposed_user_stance_matrix = np.zeros((len(self.tweet_user_index), 1))
        proposed_user_stance_matrix_confidence = np.zeros((len(self.tweet_user_index), 1))
        
        
        num_changes = 0
        proposed_changes = {}
        proposed_changes_confidence = {}
        user_stance_predictions = {}
        for user, texts in users_text.items():
            user_index = self.tweet_user_index[user]
            #if user_stance_matrix[user_index] == 0:
            if len(texts) > 0:
                predicted_texts_stance = text_clf_svm.predict(texts)
                for text_stance in predicted_texts_stance:
                    if user_index not in user_stance_predictions:
                        user_stance_predictions[user_index] = [text_stance]
                    else:
                        user_stance_predictions[user_index].append(text_stance)

        for user_index, stance_predictions in user_stance_predictions.items():
            stance, confidence = self.get_most_common_array_element_with_confidence(stance_predictions)

            if user_stance_matrix[user_index] != stance and stance != 0: #user_stance_matrix[user_index] == 0 and 
                proposed_changes[user_index] = stance
#                user_stance_matrix[user_index] = stance
                num_changes += 1
                proposed_changes_confidence[user_index] = confidence
        
            proposed_user_stance_matrix[user_index] = stance
            proposed_user_stance_matrix_confidence[user_index] = confidence
            

        return proposed_changes, proposed_changes_confidence, proposed_user_stance_matrix, proposed_user_stance_matrix_confidence
    
    
class ClassBalancer():  
    @staticmethod
    def get_stance_stats(emb, label):
        y_counts = {}
        y_Xs = {}
        y_indices = {}
        for i, (emb, label) in enumerate(zip(emb, label)):
            if label in y_counts:
                y_counts[label] = y_counts[label]  + 1
            else:
                y_counts[label] = 1    

            if label in y_Xs:
                y_Xs[label].append(emb)
            else:
                y_Xs[label] = [emb]  

            if label in y_indices:
                y_indices[label].append(i)
            else:
                y_indices[label] = [i]  

    #     print('lables : ', y_counts)

        return y_counts, y_Xs, y_indices

    @staticmethod
    def balance_stance_classes(emb_vec, labels):
        y_counts, y_Xs, y_indices = ClassBalancer.get_stance_stats(emb_vec, labels)  

        majority_label = -1
        minority_label = 1
        majority_count = 0
        for key, val in y_counts.items():
            if val > majority_count:

                minority_label = majority_label
                majority_label = key
                majority_count= val
            else:
                minority_label = key

        new_emb_vec = []    
        for label in y_counts.keys():
            if label != majority_label:
                minority_label = label

                if y_counts[majority_label] > y_counts[minority_label]:
                    additional_samples_count = y_counts[majority_label] - y_counts[minority_label]

                    indices = rd.choice(list(y_indices[minority_label]), size=additional_samples_count, replace=True)
                    for index in indices:
                        new_emb_vec.append(emb_vec[index])
                        emb_vec.append(emb_vec[index]) #, axis =0)
                        labels.append(labels[index])     


        return emb_vec, labels, new_emb_vec    
   