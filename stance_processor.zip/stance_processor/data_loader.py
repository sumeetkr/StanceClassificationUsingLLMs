import numpy as np

## Used for normalizing a vector
## a = numpy vector
def row_normalize(a):
    row_sums = a.sum(axis=1)
    new_matrix = a / (1 + row_sums[:, np.newaxis]) # 1 is added to avoid dividing by zero
    
    return new_matrix

def create_vector(user_property_count, tweet_user_index, N_TOP, binarize_count, normalize_row = False):



    hashtags_users = {} 
    hashtag_index = {}
    index_to_tag = {}
    for user, hashtags_count in user_property_count.items():
        for hashtag, count in hashtags_count.items():
            if hashtag not in hashtags_users:
                hashtags_users[hashtag] = []

            hashtags_users[hashtag].append(user)


    print('hashtags_users: ', len(hashtags_users)) 

    sorted_hashtags = sorted(hashtags_users.items(), key=lambda x: len(x[1]), reverse=True)

    print('len(user_property_count)', len(user_property_count))
    
    N_TOP = N_TOP if len(hashtags_users) > N_TOP else len(hashtags_users)
    print('N_TOP: ', N_TOP)
    
    user_hashtag_weighted_matrix = np.zeros((len(tweet_user_index), N_TOP))    

    
    
    for tag, users in sorted_hashtags[0:N_TOP]:
        for user in users:
            user_index = tweet_user_index[user]
            if tag not in hashtag_index:
                hashtag_index[tag] = len(hashtag_index)
                index_to_tag[len(hashtag_index) - 1] = tag

            tag_index = hashtag_index[tag]

            if tag in user_property_count[user]:
                user_hastag_time_used = user_property_count[user][tag]

                if binarize_count:
                    user_hashtag_weighted_matrix[user_index, tag_index] = 1
                else:
                    user_hashtag_weighted_matrix[user_index, tag_index] = user_hastag_time_used

    if normalize_row:
        normalized_user_hashtag_weighted_matrix = row_normalize(user_hashtag_weighted_matrix)
    else:
        normalized_user_hashtag_weighted_matrix = user_hashtag_weighted_matrix

    return normalized_user_hashtag_weighted_matrix, hashtag_index, index_to_tag       

# Intitalize the data structures needed for the experiment
def initialize_vectors(user_tweet_count, # a dictionary e.g.: {userid:count}, check processJson.extract_data for detials
                       user_retweet_count, # a dictionary of dictionary e.g.: {userid:{retweetUserId:count}}, check processJson.extract_data for detials
                       user_hashtag_count, # a dictionary of dictionary e.g.: {userid:{hashtag:count}}, check processJson.extract_data for detials
                       N_TOP = 100, # How many hashtags to use
                       N_TOP_RETWEET = 1000, # How many retweets to use
                      binarize_count = False, # Binarize the output matrices
                      normalize_row = False): # Normalize the output matrices
                    
    
    
    tweet_user_index = {}
    tweet_user_index_to_id = {}
    unique_users_index = {}
    users_index_to_id = {}

    for user, count in user_tweet_count.items():
        if user not in tweet_user_index:
            tweet_user_index_length = len(tweet_user_index)
            tweet_user_index[user] = tweet_user_index_length
            tweet_user_index_to_id[tweet_user_index_length] = user

        if user not in unique_users_index:
            unique_users_index_length = len(unique_users_index)
            unique_users_index[user] = unique_users_index_length
            users_index_to_id[unique_users_index_length] = user


    print('Creating retweet weight matrix')
    user_retweet_weighted_matrix, __, __ = create_vector(user_retweet_count, 
                                                         tweet_user_index, 
                                                         N_TOP_RETWEET,
                                                         binarize_count,
                                                        normalize_row = normalize_row)
    
    print('Creating hashtag weight matrix')
    user_hashtag_weighted_matrix, hashtag_index, index_to_tag = create_vector(user_hashtag_count, 
                                                                              tweet_user_index, 
                                                                              N_TOP,
                                                                              binarize_count,
                                                                             normalize_row = normalize_row)
    

    return hashtag_index, index_to_tag, tweet_user_index, users_index_to_id, user_retweet_weighted_matrix, user_hashtag_weighted_matrix

