import json
import os
import re
import sys
import json
import sys
import numpy as np
from numpy import random as rd
import random 
from collections import Counter
import unicodedata
import string
import re
import traceback

def check_module_import():
    print('data_processing_helpers loaded')
    
    
class TextProcessingHelpers():
    all_letters = string.ascii_letters + " .,;'"
    n_letters = len(all_letters)


    @staticmethod    
    def unicodeToAscii( s):
        return ''.join(
            c for c in unicodedata.normalize('NFD', s)
            if unicodedata.category(c) != 'Mn'
            and c in string.ascii_letters + " .,;'"
        )


    @staticmethod
    def clean_text(string):
        #remove @mentions
        # remove URLS
        string = re.sub(r"(?:\@|https?\://)\S+", "", string)
    #     string = string.replace('#' , '').lower()
    #     return re.sub("[^a-zA-Z]", "", string) # or should we just get unicode
        string = string.replace('RT', '')
        return TextProcessingHelpers.unicodeToAscii(string)

    @staticmethod
    def clean_tag(tag):
        pattern = re.compile('\W')
        return re.sub(pattern, '', tag)

    @staticmethod    
    def summarize_dict(user_endtag_count):
        user_count_with_endtag = 0
        for user, entag_count in  user_endtag_count.items():
            tag_count = 0
            for tag, count in entag_count.items():
                tag_count +=  count

            if tag_count > 0:
                user_count_with_endtag += 1

        return user_count_with_endtag

    @staticmethod
    def row_normalize(a):
        row_sums = a.sum(axis=1)
        new_matrix = a / (1 + row_sums[:, np.newaxis]) # 1 is added to avoid dividing by zero

        return new_matrix


    # Intitalize
    @staticmethod    
    def initialize_vectors(user_tweet_count, 
                           user_retweet_count, 
                           user_hashtag_count, 
                           N_TOP = 100,
                           N_TOP_RETWEET = 1000,
                          binarize_count = False,
                          normalize_row = False):

        def create_vector(user_property_count, tweet_user_index, N_TOP, binarize_count):
            user_hashtag_weighted_matrix = np.zeros((len(tweet_user_index), N_TOP))

            hashtags_users = {} 
            hashtag_index = {}
            index_to_tag = {}
            for user, hashtags_count in user_property_count.items():
                for hashtag, count in hashtags_count.items():
                    if hashtag not in hashtags_users:
                        hashtags_users[hashtag] = []

                    hashtags_users[hashtag].append(user)


            print('hashtags_users: ', len(hashtags_users)) 

            sorted_hashtags = sorted(hashtags_users.items(), key=lambda x: len(x[1]), reverse=True)

            for tag, users in sorted_hashtags[0:N_TOP]:
                for user in users:
                    user_index = tweet_user_index[user]
                    if tag not in hashtag_index:
                        hashtag_index[tag] = len(hashtag_index)
                        index_to_tag[len(hashtag_index) - 1] = tag

                    tag_index = hashtag_index[tag]

                    if tag in user_property_count[user]:
                        user_hastag_time_used = user_property_count[user][tag]

                        if binarize_count:
                            user_hashtag_weighted_matrix[user_index, tag_index] = 1
                        else:
                            user_hashtag_weighted_matrix[user_index, tag_index] = user_hastag_time_used

            if normalize_row:
                normalized_user_hashtag_weighted_matrix = TextProcessingHelpers.row_normalize(user_hashtag_weighted_matrix)
            else:
                normalized_user_hashtag_weighted_matrix = user_hashtag_weighted_matrix

            return normalized_user_hashtag_weighted_matrix, hashtag_index, index_to_tag       


        tweet_user_index = {}
        tweet_user_index_to_id = {}
        unique_users_index = {}
        users_index_to_id = {}

        for user, count in user_tweet_count.items():
            if user not in tweet_user_index:
                tweet_user_index_length = len(tweet_user_index)
                tweet_user_index[user] = tweet_user_index_length
                tweet_user_index_to_id[tweet_user_index_length] = user

            if user not in unique_users_index:
                unique_users_index_length = len(unique_users_index)
                unique_users_index[user] = unique_users_index_length
                users_index_to_id[unique_users_index_length] = user


        print('Creating retweet weight matrix')
        user_retweet_weighted_matrix, __, __ = create_vector(user_retweet_count, 
                                                             tweet_user_index, 
                                                             N_TOP_RETWEET,
                                                             binarize_count)

        print('Creating hashtag weight matrix')
        user_hashtag_weighted_matrix, hashtag_index, index_to_tag = create_vector(user_hashtag_count, 
                                                                                  tweet_user_index, 
                                                                                  N_TOP,
                                                                                  binarize_count)


        return hashtag_index, index_to_tag, tweet_user_index, users_index_to_id, user_retweet_weighted_matrix, user_hashtag_weighted_matrix


    @staticmethod
    def get_hashtagsall_and_at_the_end_of_sentence(text):

    #     print('orig text: ', text)
        text = text.replace('\n', '').replace(',', ' ') #.replace('http', ' http')
        words = text.split(' ')

        for word in words:
            if len(word.split('#')) > 2:
                text = text.replace(word, ' #'.join(split_word for split_word in word.split('#')))

            if '@' in word:
                if word.startswith('@'):
                    text = text.replace(word, '@user')
                else:
                    if len(word.split('@')) > 2:
                        text = text.replace(word, ' @'.join(split_word for split_word in word.split('@')))

    #     print('updated text: ', text)
        words = text.split(' ')
        end_tags = []

        tags = []
        tags_index = []
        endtag_free_text = ""

        last_plain_word_index = 0
        if len(words) > 0:
            for i, word in enumerate(words):
                if word.startswith('#'):

                    tags.append(TextProcessingHelpers.clean_tag(word.replace('#', '').lower()))
                    tags_index.append(i)
                else:
                    last_plain_word_index = last_plain_word_index +1

            for index, tag in zip(tags_index, tags):
                if index >= last_plain_word_index and len(tag) > 3:
                    end_tags.append(tag)

            for i, word in enumerate(words):
                if i < last_plain_word_index:
                    endtag_free_text = endtag_free_text  + ' ' +  word

        return tags, end_tags, TextProcessingHelpers.clean_text(endtag_free_text).lower()
    
    @staticmethod
    def find_if_retweet(tweet_text):
        is_retweet= False
        
#         if len(tweet_text.split(' ')) > 1:
#             # checking if the tweet is a retweet (this method is basic but it will work)
#             tweet_start = tweet_text.split(' ')[0]

#             if tweet_start == 'RT' and '@' in tweet_text.split(':')[0]:
#                 is_retweet = True
                
#         return is_retweet
    
    
        if tweet_text.lower().startswith("rt @") == True:
            is_retweet = True
        
        return is_retweet
            
    
    @staticmethod
    def find_if_retweet_and_return_original_user(tweet_text):
        result = None
        is_retweet= TextProcessingHelpers.find_if_retweet(tweet_text)
        
        if is_retweet and len(tweet_text.split(':')) > 0:
            tweet_start = tweet_text.split(' ')[1]
            result = re.findall("(^|[^@\w])@(\w{1,15})", tweet_start.split(':')[0])
            if len(result) > 0 and len(result[0]) > 0 :
                result = result[0][1]
           
        if isinstance(result, list):
            print('Error in parsing user',result, tweet_text) 
            result = None
            

        return is_retweet, result

    

    
class ProcessJson():

    def __init__(self):        
        all_letters = string.ascii_letters + " .,;'"
        n_letters = len(all_letters)

    # Turn a Unicode string to plain ASCII, thanks to http://stackoverflow.com/a/518232/2809427
    def retrieve_text(self, data_dict, hashtag_count, hashtag_text):
        raise NotImplementedError("error message")
            
    def extract_text_hashtags(self, tweet, 
                              hashtag_count, 
                              user_raw_text,
                              user_text,
                              endtag_count, 
                              endtags_text, 
                              hashtag_text,
                             include_retweet = True):

        text = self.retrieve_text( tweet, hashtag_count, hashtag_text)
        user_raw_text.append(text)
        
#         text = self.retrieve_text_from_tweet(self, tweet, hashtag_count, hashtag_text)

        alltags, end_tags, endtag_free_text = TextProcessingHelpers.get_hashtagsall_and_at_the_end_of_sentence(text)

        for tag in end_tags:
            if tag not in endtags_text:
                endtags_text[tag] = []
            if tag not in endtag_count:
                endtag_count[tag] = 1
            else:
                endtag_count[tag] = endtag_count[tag] + 1

            #if len(endtag_free_text) > 2:
            endtags_text[tag].append(endtag_free_text)
            
        for tag in alltags:
            if tag not in hashtag_count:
                hashtag_count[tag] = 0

            hashtag_count[tag] = hashtag_count[tag] + 1
                    
            if tag not in hashtag_text:
                hashtag_text[tag] = []
                
            #if len(endtag_free_text) > 2:
            hashtag_text[tag].append(endtag_free_text)

#         if len(endtag_free_text) > 2:
        if include_retweet:
            user_text.append(endtag_free_text)        
        elif not TextProcessingHelpers.find_if_retweet(text):
            user_text.append(endtag_free_text)        
            
        return end_tags, endtag_free_text


    def add_to_unique_users(self, unique_users, user_id):
        user_id_str = str(user_id)
        if user_id_str not in unique_users:
            unique_users[user_id_str] = 0
        else:
            unique_users[user_id_str] = unique_users[user_id_str] + 1
                

    def get_popular_hashtags_with_index(self, N_TOP):
        hashtags_users = {}
        hashtag_index = {}
        index_to_tag = {}

        for user, hashtags_count in self.user_hashtag_count.items():
            for hashtag, count in hashtags_count.items():
                if hashtag not in hashtags_users:
                    hashtags_users[hashtag] = []
                hashtags_users[hashtag].append(user)


        print('total hashtags : ', len(hashtags_users)) 

        sorted_hashtags = sorted(hashtags_users.items(), key=lambda x: len(x[1]), reverse=True)
        for tag, users in sorted_hashtags[0:N_TOP]:
        #     print(tag, len(users))
            if tag not in hashtag_index:
                hashtag_index_len = len(hashtag_index)
                hashtag_index[tag] = hashtag_index_len
                index_to_tag[hashtag_index_len] = tag

        print(len(hashtag_index))

        return hashtags_users, hashtag_index, index_to_tag, sorted_hashtags
    
    def get_users_with_index(self):
        users_index = {}
        users_index_to_id = {}
        for user, count in self.user_tweet_count.items():
            if user not in users_index: # and len(processJson.user_endtag_count[user]) > 0:
                tweet_user_index_length = len(users_index)
                users_index[user] = tweet_user_index_length
                users_index_to_id[tweet_user_index_length] = user

        print('users count: ', len(users_index))

        return users_index, users_index_to_id
    
    def extract_labels(self, label_file_path):
        user_label = {}
        with open(label_file_path) as f_read:
            for line in f_read:
                data_dict = json.loads(line)
                
                userId = data_dict['user']
                stance = data_dict['bias']

                if userId in user_label:
                    print('duplicate: ', userId)
                
                            
                if not isinstance(stance, int):
                    stance = int(stance)
                
                if stance == 2:
                    stance = 1
                elif stance == -2 :
                    stance = -1
                    
                user_label[userId] = stance
                
        self.user_label = user_label

    def extract_labels_from_text_without_tags_data(self, label_file_path):
        user_label = {}
        with open(label_file_path) as f_read:
            for line in f_read:
                # 371496460,  Prolife
                # 84603059,  Prolife
                # 40623989,  Both
                # 19979740,  Antilife

                # 170560988, AntiGC 
                # 40925820,  ProGC
                # 33265414,  ProGC
                # 1583363496,  ProGC
                # 114766980,  AntiGC

                # 321353408, AntiOC 
                # 380693277, ProOC 
                # 1380416370,  Notclear 
                # 22099720,  AntiOC

                line = line.replace(' ', '')
                if len(line.strip().split(',')) == 2:
                    
                    userId, stance = line.strip().split(',')
                    userId = int(userId)
                    stance = stance.strip().lower()

                    if 'pro' in stance:
                        stance = 1
                        user_label[userId] = stance                        
                    elif 'anti' in stance:
                        stance = -1
                        user_label[userId] = stance    
                    else:
                        
                        print('Not added to lables', userId, stance)
                else:
                    
                    print('Not added to lables 2', line, line.strip().split(','))

#                     if not isinstance(stance, int):
#                         stance = int(stance)


            
            self.user_label = {**self.user_label, **user_label}

                    
            

    
class ProcessTwitterJson(ProcessJson):
    
    def __init__(self):
        print('Twitter json prcessor')
        
    def retrieve_text(self, data_dict, hashtag_count, hashtag_text):
        if 'extended_tweet' in data_dict:
            extended_tweet = data_dict['extended_tweet']
            if 'full_text' in extended_tweet:
                text = extended_tweet['full_text']
            elif 'text' in extended_tweet:
                text = extended_tweet['text']
        elif 'full_text' in data_dict:
            text = data_dict['full_text']
        else:
            text = data_dict['text']


        tags = []
        if 'hashtags' in data_dict['entities']:
            for tag in data_dict['entities']['hashtags']:
                if 'text' in tag:
                    tag_text = tag['text'].lower()
                    tags.append(tag_text)

                    if tag_text not in hashtag_count:
                        hashtag_count[tag_text] = 0

                    hashtag_count[tag_text] = hashtag_count[tag_text] + 1

                    if tag_text not in hashtag_text:
                        hashtag_text[tag_text] = []

                    hashtag_text[tag_text].append(text)
                    
        return text
    
    def extract_data(self, tweet_file_path, include_retweet = True):
        tweets_count =0

        unique_users = {}
        user_tweet_count = {}
        user_retweeetUser = {}
        orignalUser_QuoteUser = {}
        originaUser_ReplyUser = {}
        user_hashtag_count = {}

        user_tweetid_and_retweetid_count = {}
        tweetId_text = {}

        users_text  = {}
        users_raw_text = {}
        hashtag_text = {}
        endtags_text = {}
        user_endtag_count = {}
        
        user_retweet_count = {}

        with open(tweet_file_path, 'r') as f:

            i = 0

            for line in f:
                i = i +1

        #         if i >500:
        #             break

                if len(line) <= 1:
                    continue

                try:

                    tweet = json.loads(line)
                    tweets_count = tweets_count +1


                    tweet_id = '0'
                    if 'id' in tweet:
                        tweet_id = str(tweet['id']) 

                    # print(tweet_id)

                    if tweet_id == '0':
                        continue


                    user_id = tweet['user']['id']
                    self.add_to_unique_users(unique_users, user_id)

                    if user_id not in user_tweet_count:
                        user_tweet_count[user_id] = 1
                    else:
                        user_tweet_count[user_id] = user_tweet_count[user_id] +1


                    if user_id not in user_tweetid_and_retweetid_count:
                        user_tweetid_and_retweetid_count[user_id] = {}


                    if user_id not in user_hashtag_count:
                        user_hashtag_count[user_id] = {}

                    if user_id not in user_endtag_count:
                        user_endtag_count[user_id] = {}

                    if user_id not in users_text:
                        users_text[user_id] = []
                        
                    if user_id not in users_raw_text:
                        users_raw_text[user_id] = []
                        

                    tags, endtag_free_text = self.extract_text_hashtags( tweet, user_hashtag_count[user_id], 
                                                                        users_raw_text[user_id] ,
                                                                        users_text[user_id], user_endtag_count[user_id], endtags_text, hashtag_text, include_retweet)

                    if 'retweeted_status' in tweet:
                        original_tweet = tweet['retweeted_status']

                        if 'user' in original_tweet:
                            original_user = original_tweet['user']

                            if 'id_str' in original_user:
                                original_user_id = original_user['id_str']
                                self.add_to_unique_users(unique_users, original_user_id)

                                if original_user_id not in user_retweeetUser:
                                    user_retweeetUser[original_user_id] = [user_id]
                                else:
                                    existing_retweet_users = user_retweeetUser[original_user_id]
                                    existing_retweet_users.append(user_id)
        #                             user_retweeetUser[original_user_id] = existing_retweet_users

                        if 'id_str' in original_tweet:
                            original_tweet_id = original_tweet['id_str']
        #                     print('original_tweet_id', original_tweet_id)

                            tweetId_text[original_tweet_id] = endtag_free_text

                            if original_tweet_id not in user_tweetid_and_retweetid_count[user_id]:
                                user_tweetid_and_retweetid_count[user_id][original_tweet_id] = 0
                            else:
                                user_tweetid_and_retweetid_count[user_id][original_tweet_id] \
                                    = user_tweetid_and_retweetid_count[user_id][original_tweet_id]  + 1
                                    
                                    
                            # for retweets experiments        
                            if user_id not in user_retweet_count:
                                user_retweet_count[user_id] = {}
                                
                            retweet_count = user_retweet_count[user_id]
                                
                            if original_tweet_id not in retweet_count:
                                retweet_count[original_tweet_id] = 1
                            else:
                                retweet_count[original_tweet_id] = retweet_count[original_tweet_id] + 1
                                
                    elif 'quoted_status' in tweet:
                        original_tweet = tweet['quoted_status']

                        if 'user' in original_tweet:
                            original_user = original_tweet['user']

                            if 'id_str' in original_user:
                                original_user_id = original_user['id_str']
                                self.add_to_unique_users(unique_users, original_user_id)

                                if original_user_id not in orignalUser_QuoteUser:
                                    orignalUser_QuoteUser[original_user_id] = [user_id]
                                else:
                                    existing_quote_users = orignalUser_QuoteUser[original_user_id]
                                    existing_quote_users.append(user_id)
        #                             orignalUser_QuoteUser[original_user_id] = existing_quote_users

                    elif 'in_reply_to_user_id' in tweet and tweet['in_reply_to_user_id'] is not None:
                        original_user_id = tweet['in_reply_to_user_id']
                        self.add_to_unique_users(unique_users, original_user_id)

                        if original_user_id not in originaUser_ReplyUser:
                            originaUser_ReplyUser[original_user_id] = [user_id]
                        else:
                            existing_reply_users = originaUser_ReplyUser[original_user_id]
                            existing_reply_users.append(user_id)

                    else:
                        tweetId_text[tweet_id] = endtag_free_text
                        if tweet_id not in user_tweetid_and_retweetid_count[user_id]:
                            user_tweetid_and_retweetid_count[user_id][tweet_id] = 0
                        else:
                            user_tweetid_and_retweetid_count[user_id][tweet_id] \
                                = user_tweetid_and_retweetid_count[user_id][tweet_id]  + 1

        #                 print('New tweet', tweet)


                except():
        #                         print(" could not load tweet" + line)
                            print(sys.exc_info()) 
            
        self.tweets_count = tweets_count
        print('tweets_count ', tweets_count)        

        self.unique_users = unique_users        
        print('unique_users', len(unique_users))

        self.user_retweeetUser = user_retweeetUser
        print('user_retweeetUser', len(user_retweeetUser))
        
        self.orignalUser_QuoteUser = orignalUser_QuoteUser
        print('orignalUser_QuoteUser' , len(orignalUser_QuoteUser))    
        
        self.originaUser_ReplyUser = originaUser_ReplyUser
        print('existing_reply_users', len(originaUser_ReplyUser))
        
        self.user_hashtag_count = user_hashtag_count
        print('user_hashtag_count', len(user_hashtag_count))
        
        self.users_text = users_text
        print('users_text', len(users_text))
        
        self.users_raw_text = users_raw_text
        print('users_raw_text', len(users_raw_text))
        
        
        self.user_tweet_count = user_tweet_count
        print('user_tweet_count', len(user_tweet_count))
        
        self.hashtag_text = hashtag_text
        print('hashtag_text: ', len(hashtag_text))
        
        self.endtags_text = endtags_text
        print('endtags_text:', len(endtags_text))
        
        self.user_endtag_count = user_endtag_count
        print('user_endtag_count', len(user_endtag_count))
        
        self.user_retweet_count = user_retweet_count
        print('user_retweet_count', len(user_retweet_count))
        
        print('user_tweetid_and_retweetid_count: ', len(user_tweetid_and_retweetid_count))
        
        self.tweetId_text = tweetId_text
        print('tweetId_text', len(tweetId_text))

        
class ProcessBiaswatchJson(ProcessJson):
    
    def __init__(self):        
        print('Biaswatch json processor')
        self.retweet_oring_users = {}
        
    def retrieve_text(self, data_dict, hashtag_count, hashtag_text):
        text = data_dict['text']
        return text
        
    
    def get_orig_user_index(self, user_name):
        if user_name not in self.retweet_oring_users:
            self.retweet_oring_users[user_name] = len(self.retweet_oring_users)
            
        return self.retweet_oring_users[user_name]
        
    def extract_data(self, file_path, include_retweet = True):
        tweets_count =0

        unique_users = {}
        user_tweet_count = {}
        user_retweeetUser = {}
        orignalUser_QuoteUser = {}
        originaUser_ReplyUser = {}
        user_hashtag_count = {}

        user_tweetid_and_retweetid_count = {}
        tweetId_text = {}

        users_text  = {}
        users_raw_text = {}
        hashtag_text = {}
        endtags_text = {}
        user_endtag_count = {}
        user_retweet_count = {}
        
        with open(file_path, 'r') as f:

            i = 0

            for line in f:
                i = i +1

                if len(line) <= 1:
                    continue

                try:

                    tweet = json.loads(line)
                    tweets_count = tweets_count +1

                    user_id = tweet['user']
                    self.add_to_unique_users(unique_users, user_id)

                    if user_id not in user_tweet_count:
                        user_tweet_count[user_id] = 1
                    else:
                        user_tweet_count[user_id] = user_tweet_count[user_id] +1


                    if user_id not in user_tweetid_and_retweetid_count:
                        user_tweetid_and_retweetid_count[user_id] = {}


                    if user_id not in user_hashtag_count:
                        user_hashtag_count[user_id] = {}

                    if user_id not in user_endtag_count:
                        user_endtag_count[user_id] = {}

                    if user_id not in users_text:
                        users_text[user_id] = []
                    
                    if user_id not in users_raw_text:
                        users_raw_text[user_id] = []
                        
                     

                    tags, endtag_free_text = self.extract_text_hashtags( tweet, 
                                                                        user_hashtag_count[user_id],
                                                                        users_raw_text[user_id], 
                                                                        users_text[user_id], 
                                                                        user_endtag_count[user_id],
                                                                        endtags_text, hashtag_text,
                                                                        include_retweet)
                    
                                                    
                     # for retweets experiments        
                    if user_id not in user_retweet_count:
                        user_retweet_count[user_id] = {}

                    is_retweet, orig_user = TextProcessingHelpers.find_if_retweet_and_return_original_user(self.retrieve_text(tweet, None, None))
                    if is_retweet and orig_user != None:
#                         print('orig_user', orig_user, is_retweet)
                        
                        orig_user_index = self.get_orig_user_index(orig_user)
                        retweet_count = user_retweet_count[user_id]

                        if orig_user_index not in retweet_count:
                            retweet_count[orig_user_index] = 1
                        else:
                            retweet_count[orig_user_index] = retweet_count[orig_user_index] + 1


                except():
        #                         print(" could not load tweet" + line)
                            print(sys.exc_info()) 

         
        self.tweets_count = tweets_count
        print('tweets_count ', tweets_count) 
        
        self.unique_users = unique_users        
        print('unique_users', len(unique_users))

        self.user_retweeetUser = user_retweeetUser
        print('user_retweeetUser', len(user_retweeetUser))
        
        self.orignalUser_QuoteUser = orignalUser_QuoteUser
        print('orignalUser_QuoteUser' , len(orignalUser_QuoteUser))    
        
        self.originaUser_ReplyUser = originaUser_ReplyUser
        print('existing_reply_users', len(originaUser_ReplyUser))
        
        self.user_hashtag_count = user_hashtag_count
        print('user_hashtag_count', len(user_hashtag_count))
        
        self.users_text = users_text
        print('users_text', len(users_text))
        
        self.users_raw_text = users_raw_text
        print('users_raw_text', len(users_raw_text))
        
        
        self.user_tweet_count = user_tweet_count
        print('user_tweet_count', len(user_tweet_count))
        
        self.hashtag_text = hashtag_text
        print('hashtag_text: ', len(hashtag_text))
        
        self.endtags_text = endtags_text
        print('endtags_text:', len(endtags_text))
        
        self.user_endtag_count = user_endtag_count
        print('user_endtag_count', len(user_endtag_count))

        self.user_retweet_count = user_retweet_count
        print('user_retweet_count', len(user_retweet_count))

        
        print('user_tweetid_and_retweetid_count: ', len(user_tweetid_and_retweetid_count))
        
        self.tweetId_text = tweetId_text
        print('tweetId_text', len(tweetId_text))      
            
            
            
def show_data_insights(user_endtag_count):
    endtags_users = {}
    for user, endtags_count in user_endtag_count.items():
        for endtag, count in endtags_count.items():
            if endtag not in endtags_users:
                endtags_users[endtag] = []

            endtags_users[endtag].append(user)


    print(len(endtags_users))        
    sorted_endtags = sorted(endtags_users.items(), key=lambda x: len(x[1]), reverse=True)

    print('First few endtag')
    for endtag, users in sorted_endtags[0:100]:
        print(endtag, len(users))

    print('Last few endtag')
    for endtag, users in sorted_endtags[len(sorted_endtags)-20:len(sorted_endtags) -1]:
        print(endtag, len(users))

    users_without_tag = []  
    for user, endtags_count in user_endtag_count.items():    
        user_total_count = 0
        for endtag, count in endtags_count.items():
            user_total_count +=  count

        if user_total_count == 0:
            users_without_tag.append(user)

    print('Number fo users withou tags: ', len(users_without_tag))     
    
    
    
class ClassBalancer():  
    @staticmethod
    def get_stance_stats(emb, label):
        y_counts = {}
        y_Xs = {}
        y_indices = {}
        for i, (emb, label) in enumerate(zip(emb, label)):
            if label in y_counts:
                y_counts[label] = y_counts[label]  + 1
            else:
                y_counts[label] = 1    

            if label in y_Xs:
                y_Xs[label].append(emb)
            else:
                y_Xs[label] = [emb]  

            if label in y_indices:
                y_indices[label].append(i)
            else:
                y_indices[label] = [i]  

    #     print('lables : ', y_counts)

        return y_counts, y_Xs, y_indices

    @staticmethod
    def balance_stance_classes(emb_vec, labels):
        y_counts, y_Xs, y_indices = ClassBalancer.get_stance_stats(emb_vec, labels)  

        majority_label = -1
        minority_label = 1
        majority_count = 0
        for key, val in y_counts.items():
            if val > majority_count:

                minority_label = majority_label
                majority_label = key
                majority_count= val
            else:
                minority_label = key

        new_emb_vec = []    
        for label in y_counts.keys():
            if label != majority_label:
                minority_label = label

                if y_counts[majority_label] > y_counts[minority_label]:
                    additional_samples_count = y_counts[majority_label] - y_counts[minority_label]

                    indices = rd.choice(list(y_indices[minority_label]), size=additional_samples_count, replace=True)
                    for index in indices:
                        new_emb_vec.append(emb_vec[index])
                        emb_vec.append(emb_vec[index]) #, axis =0)
                        labels.append(labels[index])     


        return emb_vec, labels, new_emb_vec
    
    