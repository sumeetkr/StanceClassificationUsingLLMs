import numpy as np
from collections import Counter
import random 
from numpy import random as rd
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score


class StanceMatricesHelper():
    
    @staticmethod
    def set_intial_tag_labels(hashtag_stance_matrix, tag_labels, hashtag_index):
        for tag, label in tag_labels.items():
            if tag in hashtag_index:
                print('Setting initial label ', tag, hashtag_index[tag], label)
                hashtag_stance_matrix[hashtag_index[tag]] = label
            else:
                print('Error in Setting initial label, tag not in hashtag_index ', tag, label)
                
            
    @staticmethod     
    def stance_label_to_index(stance):
        stance_to_index = {1:1, -1:0}
        
        return stance_to_index[stance]
        
    @staticmethod
    def set_intial_tag_labels2(hashtag_stance_matrix, tag_labels, hashtag_index):
        for tag, label in tag_labels.items():
            print('Setting initial label v2', tag, hashtag_index[tag], label)
            hashtag_stance_matrix[hashtag_index[tag], StanceMatricesHelper.stance_to_index[label]] = 1.0

            
    @staticmethod
    def propogate_labeles_from_one_matrix_to_another2(matrix_to, 
                                                     matrix_from,
                                                     weight_matrix, 
                                                     weight_threshold =1 , 
                                                     force_update = False):  
        return None
        
        
        
            
            
    @staticmethod
    def set_intial_user_labels2(user_stance_matrix, hashtag_stance_matrix, user_hashtag_weighted_matrix):
        
        num_changes, proposed_changes, proposed_changes_confidence = \
                        StanceMatricesHelper.propogate_labeles_from_one_matrix_to_another2(user_stance_matrix, 
                                                                                          hashtag_stance_matrix,
                                                                                          user_hashtag_weighted_matrix,
                                                                                          1,
                                                                                          True)
            
            
            
    @staticmethod
    def set_intial_user_labels(user_stance_matrix, hashtag_stance_matrix, user_hashtag_weighted_matrix):
        
        num_changes, proposed_changes, proposed_changes_confidence = \
                        StanceMatricesHelper.propogate_labeles_from_one_matrix_to_another(user_stance_matrix, 
                                                                                          hashtag_stance_matrix,
                                                                                          user_hashtag_weighted_matrix,
                                                                                          1,
                                                                                          True)
            
            
    @staticmethod
    def get_initialized_stance_matrices(tweet_user_index, property_count, stance_count = 1):
        
        user_stance_matrix = np.zeros((len(tweet_user_index), stance_count))
        hashtag_stance_matrix = np.zeros((property_count, stance_count))

        return user_stance_matrix, hashtag_stance_matrix 
    
    
    @staticmethod
    def get_most_common_array_element(array):

        array_witout_zero = []
        confidence = 0
        for num in array:
            if num != 0:
                array_witout_zero.append(num)

        if len(array_witout_zero)> 0:            
            b = Counter(array_witout_zero)
            most_common =  b.most_common(1)[0][0]            
            confidence = (b.most_common(1)[0][1]) /len(array_witout_zero) 

        else:
            most_common = 0
            confidence = 1.0

        return most_common, confidence
    
    
    @staticmethod
    def catgorize_matrix(user_label_matrix):
        for i in range(0, len(user_label_matrix)):
            if user_label_matrix[i] > 0:
                user_label_matrix[i] = 1
            elif user_label_matrix[i] < 0:
                user_label_matrix[i] = -1
                
        return user_label_matrix
    
    
    #StanceMatricesHelper.get_majority_labels_from_properties(matrix_from, weight_matrix, weight_threshold =1)
    @staticmethod
    def get_majority_labels_from_properties(matrix_from, weight_matrix, weight_threshold =1):
    
        row_sz, col_sz = np.shape(weight_matrix)
        user_label_matrix = np.zeros((row_sz, 1))
        
        for from_index, from_label in np.ndenumerate(matrix_from):
            to_from_weight = weight_matrix[:, from_index[0]] 
            for to_index, transfer_weight in np.ndenumerate(to_from_weight):
                to_index = to_index[0]
                user_label_matrix[to_index] = user_label_matrix[to_index] + from_label #transfer_weight*from_label
                
        StanceMatricesHelper.catgorize_matrix(user_label_matrix)
         
        return user_label_matrix
    
    
    @staticmethod
    def get_majority_label_from_estimators(prediction_arrays): #[user_prediction_from_tag, user_prediction_from_text]
        if len(prediction_arrays) ==0:
            return None
        
        stacked_array = prediction_arrays[0]
        for array in prediction_arrays[1: len(prediction_arrays)]:
            stacked_array = np.stack((stacked_array, array))
            
        sum_array = np.sum(stacked_array, axis=0)
        
        StanceMatricesHelper.catgorize_matrix(sum_array)
        
        #if undecided use text classifiers prediction
        for i in range(0, len(sum_array)):
            if sum_array[i] == 0:
                sum_array[i] = prediction_arrays[0][i]
                
        return sum_array
    
    @staticmethod
    def get_accuracy_estimate(user_labeled_stance, user_stance_matrix, tweet_user_index):

        if user_labeled_stance == None or len(user_labeled_stance) ==0:
            return 0.0, 0.0, 0.0

        predicted = []
        truths = []

        predicted_after_removing_0 = []
        truths_after_removing_0 = []
        
        predicted_after_removing_0_without_random = []
        truths_after_removing_0_without_random = []
        
        randomly_set_users = []
        
        for user_id, stance in user_labeled_stance.items():
                                    
            if user_id in tweet_user_index:
                user_index = tweet_user_index[user_id]
                user_predicted_stance = user_stance_matrix[user_index]

                predicted.append(user_predicted_stance[0])
                truths.append(stance)

                if stance != 0 and user_predicted_stance[0] != 0:
                    predicted_after_removing_0.append(user_predicted_stance[0])
                    truths_after_removing_0.append(stance)
                    
                    predicted_after_removing_0_without_random.append(user_predicted_stance[0])
                    truths_after_removing_0_without_random.append(stance)
                    
                elif stance != 0 and user_predicted_stance[0] == 0:
                    predicted_after_removing_0.append(random.choice([-1, 1])) # make random guess
                    truths_after_removing_0.append(stance)
                    randomly_set_users.append(user_id)
            else:
                print('labeled user not in dataset: ', user_id)
                    
#                 print(int(user_predicted_stance[0]), gun_stance)
        random_fraction = 1.0*len(randomly_set_users)/len(truths)

        print('Randomly set fraction of users: ', random_fraction)
    
        print( classification_report(truths_after_removing_0, predicted_after_removing_0))
        
        acc_with_unlabled_users_assignmed_random_label = accuracy_score(truths_after_removing_0, predicted_after_removing_0)
        print('Classifier Accuracy: ', acc_with_unlabled_users_assignmed_random_label)

        acc_without_unlabled_users = accuracy_score(truths_after_removing_0_without_random,
                                                    predicted_after_removing_0_without_random)
        
        print('Classifier Accuracy: ', acc_without_unlabled_users)

        
        
        return acc_with_unlabled_users_assignmed_random_label, acc_without_unlabled_users, random_fraction
    
    @staticmethod
    def binarize_matrix(user_label_matrix):
        for i in range(0, len(user_label_matrix)):
            if user_label_matrix[i] > 0:
                user_label_matrix[i] = 1
            elif user_label_matrix[i] < 0:
                user_label_matrix[i] = -1

        return user_label_matrix


    @staticmethod
    def propagate_label_with_confidence(matrix_from, matrix_from_confidence, 
                                                 weight_matrix, weight_threshold =1):
        threshold = 0

        matrix_to = np.dot(weight_matrix, np.multiply(matrix_from, matrix_from_confidence))
        matrix_to_positive = np.where( matrix_to >= threshold, 1, 0)
        matrix_to_negative = np.where( matrix_to < threshold, -1, 0)

        matrix_to_confidece  = np.divide((matrix_to_positive + matrix_to_negative), 
                                         (matrix_to_positive - matrix_to_negative))

        StanceMatricesHelper.binarize_matrix(matrix_to)
        return matrix_to, np.abs(matrix_to_confidece)

    @staticmethod
    def propogate_labeles_from_one_matrix_to_another(matrix_to, 
                                                     matrix_from,
                                                     weight_matrix, 
                                                     weight_threshold =1 , 
                                                     force_update = False):
        
        num_changes = 0
        to_label_predictions = {}
        proposed_changes = {}
        proposed_changes_confidence = {}
        for from_index, from_label in np.ndenumerate(matrix_from):
            if from_label != 0:
                to_from_weight = weight_matrix[:, from_index[0]] 
                for to_index, transfer_weight in np.ndenumerate(to_from_weight):
                    to_index = to_index[0]
#                     print(user_index, hashtag_weight)
                    if transfer_weight > weight_threshold:
                        if to_index not in to_label_predictions:
                            to_label_predictions[to_index] = [from_label]
                        else:
                            to_label_predictions[to_index].append(from_label)

        print('proposed user predictions count: ', len(to_label_predictions))                            
        
        for to_index, to_labels in to_label_predictions.items():
#             print('stance_predictions', stance_predictions)
            label, confidence = StanceMatricesHelper.get_most_common_array_element(to_labels)

            if matrix_to[to_index] != label:
                if force_update:
                    matrix_to[to_index] = label
                    num_changes += 1
                    
#                 print(user_index, stance)
                proposed_changes[to_index] = label
                proposed_changes_confidence[to_index] = confidence
                

        return num_changes, proposed_changes, proposed_changes_confidence
    
    @staticmethod
    def propgate_labels_via_tags_once(user_stance_matrix, 
                                      user_stance_matrix_confidence, 
                                      user_hashtag_weighted_matrix):
        
        user_stance_matrix_orig = np.copy(user_stance_matrix)
        user_stance_matrix_confidence_orig = np.copy(user_stance_matrix_confidence)
        
        hashtag_stance_matrix, hashtag_stance_matrix_confidence = StanceMatricesHelper.propagate_label_with_confidence(user_stance_matrix, 
                                                                     user_stance_matrix_confidence,
                                                                    np.transpose(user_hashtag_weighted_matrix))


        user_stance_matrix, user_stance_matrix_confidence = StanceMatricesHelper.propagate_label_with_confidence(hashtag_stance_matrix,
                                                                  hashtag_stance_matrix_confidence,
                                                                  user_hashtag_weighted_matrix)


        StanceMatricesHelper.binarize_matrix(user_stance_matrix)
        
        
        user_stance_matrix_orig[user_stance_matrix_orig == 0] = user_stance_matrix[user_stance_matrix_orig == 0]
        user_stance_matrix_confidence_orig[user_stance_matrix_orig == 0] = user_stance_matrix_confidence[user_stance_matrix_orig == 0]
        
        return user_stance_matrix_orig, user_stance_matrix_confidence_orig

    @staticmethod  
    def user_tag_propogator(user_stance_matrix, 
                            user_stance_matrix_confidence, 
                            user_property_weighted_matrix,
                            iteration_count = 3):

        proposed_user_stance_matrix_tag = np.copy(user_stance_matrix)
        proposed_user_stance_matrix_tag_confidence = np.copy(user_stance_matrix_confidence)
        for k in range(0, iteration_count): # iterate 3 times
            proposed_user_stance_matrix_tag, proposed_user_stance_matrix_tag_confidence = \
                StanceMatricesHelper.propgate_labels_via_tags_once(proposed_user_stance_matrix_tag,
                                                                   proposed_user_stance_matrix_tag_confidence,
                                                                   user_property_weighted_matrix)

            return proposed_user_stance_matrix_tag, proposed_user_stance_matrix_tag_confidence 
    