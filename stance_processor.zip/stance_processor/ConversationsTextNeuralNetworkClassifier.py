
import keras
import keras.backend as K
from keras.callbacks import EarlyStopping, ModelCheckpoint
from keras.layers import merge, recurrent, Dense, Input, Dropout, TimeDistributed, Concatenate, add, concatenate
from keras.layers.embeddings import Embedding
from keras.layers.normalization import BatchNormalization
from keras.layers.wrappers import Bidirectional
from keras.models import Model
from keras.preprocessing.sequence import pad_sequences
from keras.preprocessing.text import Tokenizer
from keras.regularizers import l2
from keras.utils import np_utils
from sklearn.metrics import f1_score
from keras import backend as K
import os
import tempfile
from random import shuffle

from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix
import numpy as np
from numpy import random as rd
import random 


def recall_m(y_true, y_pred):
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

def precision_m(y_true, y_pred):
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision

def f1_m(y_true, y_pred):
    precision = precision_m(y_true, y_pred)
    recall = recall_m(y_true, y_pred)
    
    return 2*((precision*recall)/(precision+recall+K.epsilon()))


def get_accuracy_estimate(truths, predicted):
#     print(type(truths))

    print(classification_report(truths, predicted))
#     print('Classifier Accuracy: ', accuracy_score(truths, predicted))

    print('f1_score micro: ', f1_score(truths, predicted, average='micro'))
    print('f1_score macro: ', f1_score(truths, predicted, average='macro'))    
    print('f1_score wieghted: ', f1_score(truths, predicted, average='weighted'))        

    return f1_score(truths, predicted, average='micro'), f1_score(truths, predicted, average='macro'), f1_score(truths, predicted, average='weighted')



def extract_tokens_from_binary_parse(parse):
    return parse.replace('(', ' ').replace(')', ' ').replace('-LRB-', '(').replace('-RRB-', ')').split()

def yield_examples(fn, skip_no_majority=True, limit=None):
  for i, line in enumerate(open(fn)):
    if limit and i > limit:
      break
    data = json.loads(line)
    label = data['gold_label']
    s1 = ' '.join(extract_tokens_from_binary_parse(data['sentence1_binary_parse']))
    s2 = ' '.join(extract_tokens_from_binary_parse(data['sentence2_binary_parse']))
    if skip_no_majority and label == '-':
      continue
    yield (label, s1, s2)

    
def yield_new_examples(replies, sources, labels, limit=None):
    all_data = (labels, sources, replies)
    for i, data in enumerate(zip(labels, sources, replies)):
        if limit and i > limit:
            break

            
        yield (data[0], data[1], data[2])


def get_data(replies, sources, labels, limit=None, shuffle_data=True):
    
    raw_data = list(yield_new_examples(replies, sources, labels, limit=limit))
    
    if shuffle_data:
        shuffle(raw_data)

    left = [s1 for _, s1, s2 in raw_data]
    right = [s2 for _, s1, s2 in raw_data]
    print(max(len(x.split()) for x in left))
    print(max(len(x.split()) for x in right))

    #   LABELS = {'contradiction': 0, 'neutral': 1, 'entailment': 2}
    Y = np.array([l - 2  for l, s1, s2 in raw_data])
    Y = np_utils.to_categorical(Y, 2)

    return left, right, Y


class ConversationsTextNNClassifier():
    def __init__(self, LAYERS = 1, USE_GLOVE = True, TRAIN_EMBED = True, EMBED_HIDDEN_SIZE = 200, SENT_HIDDEN_SIZE = 200, BATCH_SIZE = 128, PATIENCE = 4, 
        MAX_LEN = 128, DP = 0.2, L2 = 1e-5, ACTIVATION = 'relu', OPTIMIZER = 'rmsprop', glove_path = '../glove.twitter.27B/glove.twitter.27B.200d.txt',
        LABELS = {0: 2, 1: 3} , RNN = 0, lower=False):

        self.LABELS = LABELS # {0: 2, 1: 3} #, 2: 2, 3:3} # ,  {'Comment': 1, 'Queries': 0, 'Support': 2, 'Denial': 3}
        self.tokenizer = Tokenizer(lower=lower, filters='')
        
        if RNN == 0:
            self.RNN = None
        elif RNN == 1:
            self.RNN = recurrent.LSTM
        elif RNN == 2:            
            self.RNN = lambda *args, **kwargs: Bidirectional(recurrent.LSTM(*args, **kwargs))
        elif RNN == 1: 
            self.RNN = recurrent.GRU           
        else:
            self.RNN = lambda *args, **kwargs: Bidirectional(recurrent.GRU(*args, **kwargs))
        # 
        # 
        # 
        # 


        self.LAYERS = LAYERS #1 #2
        self.USE_GLOVE = USE_GLOVE #True
        self.TRAIN_EMBED = TRAIN_EMBED #True #False
        self.EMBED_HIDDEN_SIZE = EMBED_HIDDEN_SIZE #200
        self.SENT_HIDDEN_SIZE = SENT_HIDDEN_SIZE #200
        self.BATCH_SIZE = BATCH_SIZE #128
        self.PATIENCE = PATIENCE# 4 # 8
         #5 #200 #100
        self.MAX_LEN = MAX_LEN #128
        self.DP = DP #0.2
        self.L2 = L2 #1e-5 #4e-6
        self.ACTIVATION = ACTIVATION #'relu'
        self.OPTIMIZER = OPTIMIZER #'rmsprop'
        self.glove_path = glove_path #'../glove.twitter.27B/glove.twitter.27B.200d.txt'
        
    def create_embedding(self):        
        
        VOCAB = len(self.tokenizer.word_counts) + 1
        print('Build model...')
        print('Vocab size =', VOCAB)

        GLOVE_STORE = './precomputed_glove1.weights'
        if self.USE_GLOVE:
            if True : # not os.path.exists(GLOVE_STORE + '.npy')
                print('Computing GloVe')

                embeddings_index = {}
                f = open(self.glove_path) # glove.840B.300d.txt') #glove.twitter.27B.100d.txt') #+ 'glove.840B.300d.txt')
                for line in f:
                    try:
                        values = line.split(' ')
                        word = values[0]
                        coefs = np.asarray(values[1:], dtype='float32')
                        embeddings_index[word] = coefs
                    except:
                        continue
                #                 print('Error: ', values[0], values[1:])
                f.close()

                # prepare embedding matrix
                embedding_matrix = np.zeros((VOCAB, self.EMBED_HIDDEN_SIZE))
                for word, i in self.tokenizer.word_index.items():
                    embedding_vector = embeddings_index.get(word)
                    if embedding_vector is not None:
                    # words not found in embedding index will be all-zeros.
                        embedding_matrix[i] = embedding_vector
                #           else:
                #             print('Missing from GloVe: {}'.format(word))

                np.save(GLOVE_STORE, embedding_matrix)


                print('Loading GloVe')
                embedding_matrix = np.load(GLOVE_STORE + '.npy')

                print('Total number of null word embeddings:')
                print(np.sum(np.sum(embedding_matrix, axis=1) == 0))

                self.embed = Embedding(VOCAB, self.EMBED_HIDDEN_SIZE, weights=[embedding_matrix], input_length=self.MAX_LEN, trainable=self.TRAIN_EMBED)
            else:
                self.embed = Embedding(VOCAB, self.EMBED_HIDDEN_SIZE, input_length=self.MAX_LEN)

    def fit(self, train_sources, train_replies, train_labels, validatation_data = None, max_epochs = 10):
        MAX_EPOCHS = max_epochs

        print('RNN / Embed / Sent = {}, {}, {}'.format(self.RNN, self.EMBED_HIDDEN_SIZE, self.SENT_HIDDEN_SIZE))
        print('GloVe / Trainable Word Embeddings = {}, {}'.format(self.USE_GLOVE, self.TRAIN_EMBED))
        
        
        if validatation_data == None:
            validation_count = int(0.1 * len(train_replies))


            validation = get_data(train_replies[0:validation_count]
                              ,train_sources[0:validation_count]
                              ,train_labels[0:validation_count])


            training = get_data(train_replies[validation_count+1:], 
                        train_sources[validation_count+1:],
                        train_labels[validation_count+1:])
        else:
            
            test_replies, test_sources, test_labels, = validatation_data
            validation = get_data(test_replies
                              ,test_sources
                              ,test_labels)


            training = get_data(train_replies, 
                        train_sources,
                        train_labels)


        
        self.tokenizer.fit_on_texts(training[0] + training[1])
        self.create_embedding()

        # Lowest index from the tokenizer is 1 - we need to include 0 in our vocab count

                  



        to_seq = lambda X: pad_sequences(self.tokenizer.texts_to_sequences(X), maxlen=self.MAX_LEN)
        prepare_data = lambda data: (to_seq(data[0]), to_seq(data[1]), data[2])

        training = prepare_data(training)
        validation = prepare_data(validation)

         
        rnn_kwargs = dict(output_dim=self.SENT_HIDDEN_SIZE, dropout_W=self.DP, dropout_U=self.DP)
        SumEmbeddings = keras.layers.core.Lambda(lambda x: K.sum(x, axis=1), output_shape=(self.SENT_HIDDEN_SIZE, ))

        translate = TimeDistributed(Dense(self.SENT_HIDDEN_SIZE, activation= self.ACTIVATION))

        premise = Input(shape=(self.MAX_LEN,), dtype='int32')
        hypothesis = Input(shape=(self.MAX_LEN,), dtype='int32')

        prem = self.embed(premise)
        hypo = self.embed(hypothesis)

        prem = translate(prem)
        hypo = translate(hypo)

    #     if RNN and LAYERS > 1:
    #       for l in range(LAYERS - 1):
    #         rnn = RNN(return_sequences=True, **rnn_kwargs)
    #         prem = BatchNormalization()(rnn(prem))
    #         hypo = BatchNormalization()(rnn(hypo))
            
        rnn = SumEmbeddings if not self.RNN else self.RNN(return_sequences=False, **rnn_kwargs)
        prem = rnn(prem)
        hypo = rnn(hypo)
        prem = BatchNormalization()(prem)
        hypo = BatchNormalization()(hypo)

        joint = concatenate([prem, hypo]) #merge([prem, hypo], mode='concat')
        joint = Dropout(self.DP)(joint)

        for i in range(self.LAYERS):
          joint = Dense(2 * self.SENT_HIDDEN_SIZE, activation= self.ACTIVATION, W_regularizer=l2(self.L2) if self.L2 else None)(joint)
          joint = Dropout(self.DP)(joint)
          joint = BatchNormalization()(joint)

        pred = Dense(len(self.LABELS), activation='softmax')(joint)

        self.model = Model(input=[premise, hypothesis], output=pred)
        self.model.compile(optimizer= self.OPTIMIZER, 
                      loss='categorical_crossentropy', 
                      metrics=['accuracy', 
                               f1_m])

    #     model.summary()

        print('Training')
        _, tmpfn = tempfile.mkstemp()
        self.tmpfn = tmpfn
        
        # Save the best model during validation and bail out of training early if we're not improving
        callbacks = [EarlyStopping(patience = self.PATIENCE), ModelCheckpoint(tmpfn, save_best_only=True, save_weights_only=True)]
        self.model.fit([training[0], training[1]], training[2], batch_size=self.BATCH_SIZE, nb_epoch= MAX_EPOCHS, validation_data=([validation[0], validation[1]], validation[2]), callbacks=callbacks)


    def predict(self, test_sources, test_replies, test_labels, clear_session = True):

        all_test = get_data(test_replies, 
                    test_sources,
                    test_labels, 
                    shuffle_data = False)    


        to_seq = lambda X: pad_sequences(self.tokenizer.texts_to_sequences(X), maxlen= self.MAX_LEN)
        prepare_data = lambda data: (to_seq(data[0]), to_seq(data[1]), data[2])

        # test = prepare_data(test)
        # all_predicted = prepare_data(all_predicted) 
        all_test = prepare_data(all_test)

        # Restore the best found model during validation
        self.model.load_weights(self.tmpfn)

        # loss, acc, f1 = model.evaluate([test[0], test[1]], test[2], batch_size=self.BATCH_SIZE)
        # print('Test loss / test accuracy / test f1 = {:.4f} / {:.4f} / {:.4f}'.format(loss, acc, f1))    
        
        
        y_classes_probab = self.model.predict([all_test[0], all_test[1]], verbose=1)
        y_classes = y_classes_probab.argmax(axis= -1)
        y_truths = all_test[2].argmax(axis= -1)
        
        
        
        # y_predicted_probab = model.predict([all_predicted[0], all_predicted[1]], verbose=1)
        # y_predicted_classes = y_predicted_probab.argmax(axis= -1)

        
        
        f1_micro, f1_macro,  f1_weighted = get_accuracy_estimate(y_truths, y_classes)
    #     print('f1_val micro', f1_val)
        
        if clear_session:
            keras.backend.clear_session()
            os.remove(self.tmpfn)

        return y_classes