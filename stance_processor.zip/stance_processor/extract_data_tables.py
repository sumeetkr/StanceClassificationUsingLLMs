import re
import json
import ast
import sys
import random
import json
import math
import os
import os.path
import sys
import csv
import pandas as pd
import unicodedata
import string
import re
import traceback

from urllib.parse import urlparse

class DataTablesCreator():

    def __init__(self, tweets_path, topic_name ='twitter_analysis', write_path = './'):
        self.event_of_interest = topic_name
        self.tweetsPath = tweets_path
        self.write_path = write_path


    def get_text(self, tweet):
        tweetText = re.sub(r"(?:\@|https?\://)\S+", "", tweet) # r'(?:@[\w_]+)'
        tweetText = tweetText.strip().replace('rt', '').replace('\n', ' ').replace('\r', ' ').replace('\t', ' ')
        
        return tweetText

    @staticmethod
    def write_dict_to_file(originalUser_retweeetUser, 
                           event_of_interest, 
                           header_data = ['source_tweet_user'
                                          ,'retweet_user',
                                         'count'],
                           file_name = "retweets_weighted.csv",
                           data_write_path = './'):

        with open(data_write_path  + file_name, 'w') as f_write:

    #         print('len(originalUser_retweeetUser): ', len(originalUser_retweeetUser))
            retweetUser_origUser_weighted = {}
            retweeetUser_unique = {}
            for originalUser, retweeetUsers in originalUser_retweeetUser.items():
                for retweeetUser in retweeetUsers:
                    user_key = str(originalUser) + '_' + str(retweeetUser)

                    if originalUser not in retweeetUser_unique:
                        retweeetUser_unique[originalUser] = 0

                    retweeetUser_unique[originalUser] += 1

                    if user_key not in retweetUser_origUser_weighted:
                        retweetUser_origUser_weighted[user_key] = 1
                    else:
                        retweetUser_origUser_weighted[user_key] += 1

    #         print('len(retweetUser_origUser_weighted): ', len(retweetUser_origUser_weighted))            
    #         print('len(retweeetUser_unique): ', len(retweeetUser_unique))

            f_write.write("{},{},{}\n".format( header_data[0], header_data[1], header_data[2]))
            for retweetUser_origUser, weight in retweetUser_origUser_weighted.items():
                origUser, retweetUser  = retweetUser_origUser.split('_')
                f_write.write("{},{},{}\n".format( origUser, retweetUser, weight))

    @staticmethod
    def write_simple_dict_to_file(user_endtags, event_of_interest, header_data = ['source_tweet_user'
                                                                                  ,'retweet_user',
                                                                                 'count'],
                                  file_name = "retweets_weighted.csv",
                                  data_write_path = './'):
        

        with open(data_write_path  + file_name, 'w') as f_write:
            f_write.write("{},{},{}\n".format( header_data[0], header_data[1], header_data[2]))
            for user, endtagsCount in user_endtags.items():
                for endtag, count in endtagsCount.items():
                    f_write.write("{},{},{}\n".format( user, endtag, count))

    @staticmethod
    def write_text_dict_to_file(user_texts, event_of_interest, 
                                file_name = "retweets_weighted.csv",
                                data_write_path = './'):
        
        with open(data_write_path + file_name, 'w') as f_write:
            for user, dictionaries in user_texts.items():
                for dictionary in dictionaries:
                    f_write.write("{}\n".format(json.dumps({'user': user, 'data': dictionary})))
                    
                    
                
    all_letters = string.ascii_letters + " .,;'"
    n_letters = len(all_letters)

    @staticmethod
    def unicodeToAscii(s):
        return ''.join(
            c for c in unicodedata.normalize('NFD', s)
            if unicodedata.category(c) != 'Mn'
            and c in string.ascii_letters + " .,;'"
        )            

    @staticmethod
    def clean_text(string):
        #remove @mentions
        # remove URLS
        string = re.sub(r"(?:\@|https?\://)\S+", "", string)
    #     string = string.replace('#' , '').lower()
    #     return re.sub("[^a-zA-Z]", "", string) # or should we just get unicode
        string = string.replace('RT', '')
        return unicodeToAscii(string)


    @staticmethod
    def clean_tag(tag):
        pattern = re.compile('\W')
        return re.sub(pattern, '', tag)            
                
    @staticmethod                
    def get_hashtagsall_and_at_the_end_of_sentence(text):

            text = text.replace('\n', '').replace(',', ' ') #.replace('http', ' http')
            words = text.split(' ')

            for word in words:
                if len(word.split('#')) > 2:
                    text = text.replace(word, ' #'.join(split_word for split_word in word.split('#')))

                if '@' in word:
                    if word.startswith('@'):
                        text = text.replace(word, '@user')
                    else:
                        if len(word.split('@')) > 2:
                            text = text.replace(word, ' @'.join(split_word for split_word in word.split('@')))

        #     print('updated text: ', text)
            words = text.split(' ')
            end_tags = []

            tags = []
            tags_index = []
            endtag_free_text = ""

            last_plain_word_index = 0
            if len(words) > 0:
                for i, word in enumerate(words):
                    if word.startswith('#'):

                        tags.append(DataTablesCreator.clean_tag(word.replace('#', '').lower()))
                        tags_index.append(i)
                    else:
                        last_plain_word_index = last_plain_word_index +1

                for index, tag in zip(tags_index, tags):
                    if index >= last_plain_word_index and len(tag) > 3:
                        end_tags.append(tag)

                for i, word in enumerate(words):
                    if i < last_plain_word_index:
                        endtag_free_text = endtag_free_text  + ' ' +  word

            return tags, end_tags, endtag_free_text.replace('\t', ' ') # clean_text().lower()            
        
        
    @staticmethod
    def retrieve_text(data_dict):
        if 'extended_tweet' in data_dict:
            extended_tweet = data_dict['extended_tweet']
            if 'full_text' in extended_tweet:
                text = extended_tweet['full_text']
            elif 'text' in extended_tweet:
                text = extended_tweet['text']
        elif 'full_text' in data_dict:
            text = data_dict['full_text']
        else:
            text = data_dict['text']   
            
        return text.replace('\n', '').replace('\r', '').replace('\t', '')

    def add_tag_to_user_dict(self, user_endtags_count, end_tags, user_id):
        if user_id not in user_endtags_count:
            user_endtags_count[user_id] = {}

        user_endtags = user_endtags_count[user_id] 

        for tag in end_tags:
            if tag not in user_endtags:
                user_endtags[tag] = 1
            else:
                user_endtags[tag] += 1    
                

    @staticmethod
    def get_domains_from_tweet(tweet):
        urls = [] 
        full_urls = []
        if 'entities' in tweet: 
            if 'urls' in  tweet['entities']:  

                for url in tweet['entities']['urls']:
                    expanded_url = ''
                    if 'expanded_url' in url:
                        expanded_url = url['expanded_url']#.encode('utf-8')
                    else:
                        expanded_url = url['display_url']

                    if len(expanded_url) > 2:

                        parsed_uri = urlparse(expanded_url )    
                        domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)

                        rootName = domain #.split('.')[len(domain.split('.'))-2]
                        rootName = rootName.replace('http://', '')
                        rootName = rootName.replace('https://', '')

                        rootName = rootName.split('/')[0] # get only root

                        urls.append(rootName)
                        full_urls.append(expanded_url)

        return urls, full_urls



    @staticmethod
    def get_media_url_from_tweet(tweet):
        urls = [] 
        full_urls = []
        if 'entities' in tweet: 
            if 'media' in  tweet['entities']:  
                for media in tweet['entities']['media']:
                    expanded_url = ''
                    if 'media_url' in media:
                        expanded_url = media['media_url']#.encode('utf-8')
                    else:
                        expanded_url = media['media_url_https']

                    if len(expanded_url) > 2 :

                        full_urls.append(expanded_url)

                        parsed_uri = urlparse(expanded_url )    
                        domain = '{uri.scheme}://{uri.netloc}/'.format(uri=parsed_uri)

                        rootName = domain #.split('.')[len(domain.split('.'))-2]
                        rootName = rootName.replace('http://', '')
                        rootName = rootName.replace('https://', '')

                        rootName = rootName.split('/')[0] # get only root

                        urls.append(rootName)

        return urls, full_urls



                        
    @staticmethod        
    def get_mentions_from_tweet(tweet):
        mentions = [] 
        if 'entities' in tweet: 
            if 'user_mentions' in tweet['entities']:   
                for mention in tweet['entities']['user_mentions']:
                    if 'id_str' in mention:
                        mentions.append(mention['id_str'])

        return mentions
                            
                            


    # Now lets process data for users' timeline that Binxuan gave

    def extract_data(self, write_all_json = False): #tweetsPath, event_of_interest ='twitter_analysis', write_path = './'

        event_of_interest = self.event_of_interest
        tweetsPath = self.tweetsPath 
        write_path = self.write_path


        # root_folder = './' + event_of_interest + '/'
        if not os.path.exists(tweetsPath):
            os.makedirs(tweetsPath)


        data_write_path = write_path + event_of_interest 

        if not os.path.exists(data_write_path):
            os.makedirs(data_write_path)

        data_write_path = data_write_path + '/'

        tweets_path_write = data_write_path + "/filtered_tweets.json.data"    


        print('event_of_interest: ', event_of_interest)
        
        # Browse all tweets in the raw folder
        # Collect all tweets, retweets from the users of intereset 
        # or replies, quotes mentioning the users of intereset 
        files = []
        for file_name in os.listdir(tweetsPath):
            if file_name.endswith(".json"):
                files.append(tweetsPath + "/" + file_name)

        print('files for : ' , event_of_interest, len(files))


        conversationTweetId_text = {}
        conversationTweetId_with_no_text = {}
        for fname in files :
            m = 0
            file_name = fname.split('/')[len(fname.split('/')) -1]
            with open(fname, 'r') as f:
                print('loading file text in memory ', file_name)
                for line in f:
                    if len(line) <= 1:
                        continue

                    try:
                        m += 1
                        #if m > 5000:
                        #    break

                                    
                        tweet = json.loads(line)
                        tweet_id = '0'
                        if 'id' in tweet:
                            tweet_id = str(tweet['id']) 

                        if tweet_id == '0':
                            continue

                                        
                        text = DataTablesCreator.retrieve_text(tweet)
                        if tweet_id not in conversationTweetId_text:
                            conversationTweetId_text[tweet_id] = text

                    except:
                        continue
                
                print('Now size conversationTweetId_text: ', len(conversationTweetId_text))
                        
        print('Total conversationTweetId_text: ', len(conversationTweetId_text))
                            
        
        tweets_count = 0
        useful_tweets_count = 0
        unique_users = {}
        
        originalUser_retweeetUser = {}
        orignalUser_QuoteUser = {}
        originaUser_ReplyUser = {}

        originaUser_without_ReplyQuoteOrRetweet = {}
        
        user_hashtags_count = {}
        user_endtags_count = {}
        user_text= {}
        
        user_mention_count = {}
        user_url_count = {}
        user_full_url_count = {} 

        user_media_url_count = {}
        user_media_full_url_count = {}


        tweet_ids_processed = {}

        

        with open(tweets_path_write, 'w' ) as f_write:
            with open(data_write_path  + "filtered_tweets_without_ReplyQuoteOrRetweet.json", 'w' ) as f_write2:
                with open(data_write_path  + "filtered_tweets_conversations.tsv", 'w' ) as f_write4:
                    with open(data_write_path + "filtered_tweets_conversations_for_labeled_users.tsv", 'w' ) as f_write5:
                        f_write4.write("{}\t{}\t{}\t{}\t{}\t{}\n".format('source_tweet_id', 'sourse_user_id', 'source_text', 'reply_tweet_id', 'reply_user_id', 'reply_text'))
                        f_write5.write("{}\t{}\t{}\t{}\t{}\t{}\n".format('source_tweet_id', 'sourse_user_id', 'source_text', 'reply_tweet_id', 'reply_user_id', 'reply_text'))
                        for fname in files:
                            file_name = fname.split('/')[len(fname.split('/')) -1]
                            print('checking if out exists for file ', file_name)

                        #     if file_name not in outputFiles:
                            print('processing file ', file_name)
                            i = 0
                            with open(fname, 'r') as f:
                                for line in f:
                                    i = i +1

                                    #if i > 5000:
                                    #    break

                                    if len(line) <= 1:
                                        continue

                                    try:
                                        tweet = json.loads(line)
                                        tweets_count = tweets_count +1

                                        tweet_id = '0'
                                        if 'id' in tweet:
                                            tweet_id = str(tweet['id']) 

                                        if tweet_id == '0' or tweet_id in tweet_ids_processed:
                                            continue

                                        tweet_ids_processed[tweet_id] = 1

                                        user_id = tweet['user']['id_str']

                                        text = DataTablesCreator.retrieve_text(tweet)

                                        hashtags, end_tags, endtag_free_text_lower  = DataTablesCreator.get_hashtagsall_and_at_the_end_of_sentence(text)

                                        self.add_tag_to_user_dict(user_endtags_count, end_tags, user_id)   
                                        self.add_tag_to_user_dict(user_hashtags_count, hashtags, user_id)

                                        urls, full_urls = DataTablesCreator.get_domains_from_tweet(tweet)

                                        self.add_tag_to_user_dict(user_url_count, urls, user_id)
                                        self.add_tag_to_user_dict(user_full_url_count, full_urls, user_id)


                                        media_urls, media_full_urls = DataTablesCreator.get_media_url_from_tweet(tweet)
                                        self.add_tag_to_user_dict(user_media_url_count, media_urls, user_id)
                                        self.add_tag_to_user_dict(user_media_full_url_count, media_full_urls, user_id)

                                        
                                        
                                        mentions = DataTablesCreator.get_mentions_from_tweet(tweet)
                                        self.add_tag_to_user_dict(user_mention_count, mentions, user_id)
                                        
                                        if user_id not in user_text:
                                            user_text[user_id] = []

                                        is_useful_condition = lambda  user_id, original_user_id: True # in users_of_interest or original_user_id in users_of_interest

                                        if 'retweeted_status' in tweet:
                                            original_tweet = tweet['retweeted_status']

                                            if 'user' in original_tweet:
                                                original_user = original_tweet['user']

                                                if 'id_str' in original_user:
                                                    original_user_id = original_user['id_str']

                                                    if is_useful_condition(user_id, original_user_id):
                                                        
                                                        user_text[user_id].append({'Type': 'RT', 
                                                                                   'TweetId' : tweet_id, 
                                                                                   'Text':text})

                                                        if write_all_json:
                                                            f_write.write(line)

                                                        useful_tweets_count += 1

                                                        if original_user_id not in originalUser_retweeetUser:
                                                            originalUser_retweeetUser[original_user_id] = [user_id]
                                                        else:
                                                            existing_retweet_users = originalUser_retweeetUser[original_user_id]
                                                            existing_retweet_users.append(user_id)

                                        elif 'quoted_status' in tweet:
                                            original_tweet = tweet['quoted_status']

                                            if 'user' in original_tweet:
                                                original_user = original_tweet['user']

                                                if 'id_str' in original_user:
                                                    original_user_id = original_user['id_str']

                                                    if is_useful_condition(user_id, original_user_id):                            
                                                        user_text[user_id].append({'Type':'QT',
                                                                                   'TweetId' : tweet_id, 
                                                                                   'Text':text})

                                                        if write_all_json:
                                                            f_write.write(line)

                                                        useful_tweets_count += 1

                                                        if original_user_id not in orignalUser_QuoteUser:
                                                            orignalUser_QuoteUser[original_user_id] = [user_id]
                                                        else:
                                                            existing_quote_users = orignalUser_QuoteUser[original_user_id]
                                                            existing_quote_users.append(user_id)

                                        elif 'in_reply_to_status_id_str' in tweet and tweet['in_reply_to_status_id_str'] is not None :
                                            reply_tweet_id = tweet['in_reply_to_status_id_str']

                                            if len(reply_tweet_id)> 0: 
                                                original_user_id = tweet['in_reply_to_user_id']

                                                source_text = ""
                                                if reply_tweet_id in conversationTweetId_text:
                                                    source_text  = conversationTweetId_text[reply_tweet_id]
                                                else:
                                                    conversationTweetId_with_no_text[reply_tweet_id] = 1

                                                f_write4.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(reply_tweet_id, original_user_id, source_text,
                                                                                                 tweet_id, user_id, text ))
                                                
                                                if is_useful_condition(user_id, original_user_id): 
                                                    user_text[user_id].append({'Type':'RL',
                                                                                   'TweetId' : tweet_id, 
                                                                                   'Text':text})

                                                        
                                                    f_write5.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(reply_tweet_id, original_user_id, source_text,
                                                                                                     tweet_id, user_id, text))
                                                    
                                                    if write_all_json:
                                                        f_write.write(line)
                                                        
                                                    useful_tweets_count += 1

                                                    if original_user_id not in originaUser_ReplyUser:
                                                        originaUser_ReplyUser[original_user_id] = [user_id]
                                                    else:
                                                        existing_reply_users = originaUser_ReplyUser[original_user_id]
                                                        existing_reply_users.append(user_id)

                                        else:
                                            if is_useful_condition(user_id, original_user_id):
                                                user_text[user_id].append({'Type':'NA',
                                                                           'TweetId' : tweet_id, 
                                                                           'Text':text})                                            
                                                f_write2.write(line)
                                                if user_id not in originaUser_without_ReplyQuoteOrRetweet:
                                                    originaUser_without_ReplyQuoteOrRetweet[user_id] = 1
                                                else:
                                                    originaUser_without_ReplyQuoteOrRetweet[user_id] += 1


                                    except:
                                        print(sys.exc_info()) 
                                        continue

                        #                         break

                            print( file_name, ' lines procssed:',  i, 'useful_tweets_count', useful_tweets_count)

        print(event_of_interest, tweets_count)         

        print('originalUser_retweeetUser: ', len(originalUser_retweeetUser))
        print('orignalUser_QuoteUser: ' , len(orignalUser_QuoteUser))
        print('originaUser_ReplyUser: ', len(originaUser_ReplyUser))
        print('originaUser_without_ReplyQuoteOrRetweet:', len(originaUser_without_ReplyQuoteOrRetweet))
        print('user_hashtags_count: ', len(user_hashtags_count))
        print('user_endtags_count: ', len(user_endtags_count))
        print('user_text: ', len(user_text))
        print('conversationTweetId_with_no_text: ', len(conversationTweetId_with_no_text))
            
        DataTablesCreator.write_dict_to_file(originalUser_retweeetUser, 
                           event_of_interest,
                           header_data = ['source_tweet_user'
                                          ,'retweet_user',
                                         'count'], 
                           file_name = "retweets_weighted.csv",
                           data_write_path = data_write_path)  
        
        DataTablesCreator.write_dict_to_file(orignalUser_QuoteUser, 
                           event_of_interest, 
                           header_data = ['source_tweet_user'
                                          ,'quote_user',
                                         'count'], 
                           file_name = "quotes_weighted.csv",
                           data_write_path = data_write_path)  
        
        DataTablesCreator.write_dict_to_file(originaUser_ReplyUser, 
                           event_of_interest, 
                           header_data = ['source_user'
                                          ,'reply_user',
                                         'count'], 
                           file_name = "replies_weighted.csv",
                           data_write_path = data_write_path)  
        
        DataTablesCreator.write_simple_dict_to_file(user_hashtags_count, 
                                  event_of_interest, 
                           header_data = ['user'
                                          ,'hashtag',
                                         'count'],
                                  file_name = "hashtags_weighted.csv",
                                  data_write_path = data_write_path)
        
        DataTablesCreator.write_simple_dict_to_file(user_endtags_count, 
                                  event_of_interest , 
                                   header_data = ['user'
                                          ,'endtag',
                                         'count'],
                                  file_name = "endtags_weighted.csv",
                                  data_write_path = data_write_path)
        
        DataTablesCreator.write_simple_dict_to_file(user_mention_count, 
                                  event_of_interest, 
                                   header_data = ['user'
                                          ,'mention',
                                         'count'],
                                  file_name = "mentions_weighted.csv",
                                  data_write_path = data_write_path)
        
        DataTablesCreator.write_simple_dict_to_file(user_url_count, 
                                  event_of_interest, 
                                   header_data = ['user'
                                          ,'url',
                                         'count'],
                                  file_name = "urls_weighted.csv",
                                  data_write_path = data_write_path)


        DataTablesCreator.write_simple_dict_to_file(user_full_url_count, 
                                  event_of_interest, 
                                   header_data = ['user'
                                          ,'url',
                                         'count'],
                                  file_name = "fullurls_weighted.csv",
                                  data_write_path = data_write_path)
        
        
        DataTablesCreator.write_simple_dict_to_file(user_media_url_count, 
                                  event_of_interest, 
                                   header_data = ['user'
                                          ,'url',
                                         'count'],
                                  file_name = "media_urls_weighted.csv",
                                  data_write_path = data_write_path)


        DataTablesCreator.write_simple_dict_to_file(user_media_full_url_count, 
                                  event_of_interest, 
                                   header_data = ['user'
                                          ,'url',
                                         'count'],
                                  file_name = "media_fullurls_weighted.csv",
                                  data_write_path = data_write_path)


        DataTablesCreator.write_text_dict_to_file(user_text, 
                                    event_of_interest, 
                                    file_name = "users_text.tsv",
                                    data_write_path = data_write_path)
                                
        with open(data_write_path  + "originaUser_without_ReplyQuoteOrRetweet.csv", 'w' ) as f_write3:
            for user, count in originaUser_without_ReplyQuoteOrRetweet.items():
                f_write3.write("{},{}\n".format(user, count))



# extract_data('./fauci/', 'fauci')
            


        









