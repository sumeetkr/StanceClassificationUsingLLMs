import numpy as np

class TextDataHandler():
    def __init__(self, users_text, endtags_text):
        print('TextDataHandler')
        self.users_text = users_text
        self.endtags_text = endtags_text
    
    def get_users_text(self):
        return self.users_text
    
    def get_text_data_from_tags(self, tag_labels):
        pro_texts = []
        anti_texts = []
        for tag, label in tag_labels.items():
            print(tag, label)
            if tag in self.endtags_text and len(self.endtags_text[tag]) > 0:
                if label == 1:
                    pro_texts.extend(self.endtags_text[tag])
                elif label == -1:
                    anti_texts.extend(self.endtags_text[tag])
                else:
                    print('Problems', tag, label) 
            else:
                print('No text for: ', tag)
                    

        print('Train data:', len(pro_texts), len(anti_texts))

        return pro_texts, anti_texts
    
    
    def get_user_labels_from_tag_labels(self, tag_labels):
        
        pro_users = []
        anti_users = []
        for tag, label in tag_labels.items():
            print(tag, label)
            
            if tag in self.endtags_text and len(self.endtags_text[tag]) > 0:
                if label == 1:
                    pro_texts.extend(self.endtags_text[tag])
                elif label == -1:
                    anti_texts.extend(self.endtags_text[tag])
                else:
                    print('Problems', tag, label) 
            else:
                print('No text for: ', tag)
                    

        print('Train data:', len(pro_texts), len(anti_texts))
        

    def get_text_data_from_user_labels(self, user_stance_matrix, \
                                       users_index_to_id):
        
        pro_users_texts = []
        anti_users_texts = []

        for user_index, user_stance in np.ndenumerate(user_stance_matrix):
            if user_stance != 0:
                user_index = user_index[0]
                user_id = users_index_to_id[user_index]
                if user_id in self.users_text:
                    texts = self.users_text[user_id]
                    if len(texts) > 0:
                        if user_stance == 1:
                            pro_users_texts.extend(texts)
                        elif user_stance == -1:
                            anti_users_texts.extend(texts)
    #                         anti_user_ids.extend([user_id]*len(texts))
                        else:
                            print('Problems', user_id, stance)
#                 else:
                        
#                     print(str(user_id) , ' not in users_text' )
               
        print('Test Pro data:', len(pro_users_texts), 'Test Anti data:', len(anti_users_texts))
        return pro_users_texts, anti_users_texts
    
    def get_test_text_data(self, labeled_user_stance):
        pro_user_ids = []
        anti_user_ids = []
        
        test_pro_texts = []
        test_anti_texts = []
        for user_id, stance in labeled_user_stance.items():
            
            if not isinstance(stance, int):
                stance = int(stance)
                
            if user_id in self.users_text:
                texts = self.users_text[user_id]
                if stance == 1 or stance == 2:
                    test_pro_texts.extend(texts)
                    pro_user_ids.extend([user_id]*len(texts))
                elif stance == -1 or stance == -2:
                    test_anti_texts.extend(texts)
                    anti_user_ids.extend([user_id]*len(texts))
                else:
                    print('Problems', user_id, stance)
            else:
                print(str(user_id) , ' not in users_text' )

        print('Test Pro data:', len(test_pro_texts), 'Test Anti data:', len(test_anti_texts))
        return test_pro_texts, test_anti_texts, pro_user_ids, anti_user_ids
    
    
    