from sklearn.metrics import f1_score
import json

import re
import json
import ast
import sys
import random
import json
import math
import os
import os.path
import sys
import csv

import numpy as np
from numpy import random as rd
import random 
from collections import Counter
import unicodedata
import string
import re
import traceback
# from joblib import Parallel, delayed
# import sklearn

from sklearn.feature_selection import mutual_info_classif
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from sklearn.pipeline import Pipeline

from sklearn.neural_network import MLPClassifier
from sklearn.linear_model import SGDClassifier
# from xgboost.sklearn import XGBClassifier
# import xgboost as xgb


from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.feature_extraction.text import CountVectorizer

from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix

import pandas as pd
from random import shuffle
from numpy import random as rd

def get_statce_stats(emb, label):
    y_counts = {}
    y_Xs = {}
    y_indices = {}
    for i, (emb, label) in enumerate(zip(emb, label)):
        if label in y_counts:
            y_counts[label] = y_counts[label]  + 1
        else:
            y_counts[label] = 1    

        if label in y_Xs:
            y_Xs[label].append(emb)
        else:
            y_Xs[label] = [emb]  
            
        if label in y_indices:
            y_indices[label].append(i)
        else:
            y_indices[label] = [i]  

    print('lables : ', y_counts)
    
    return y_counts, y_Xs, y_indices

def balance_stance_classes(emb_vec, labels):
    y_counts, y_Xs, y_indices = get_statce_stats(emb_vec, labels)  
    
        
    majority_label = 0
    minority_label = 1
    majority_count = 0
    for key, val in y_counts.items():
        if val > majority_count:
            
            minority_label = majority_label
            majority_label = key
            majority_count= val
        else:
            minority_label = key
        
    new_emb_vec = []    
    new_labels = []
    for label in y_counts.keys():
        if label != majority_label:
            minority_label = label
            
            if y_counts[majority_label] > y_counts[minority_label]:
                additional_samples_count = y_counts[majority_label] - y_counts[minority_label]

                indices = rd.choice(list(y_indices[minority_label]), size=additional_samples_count, replace=True)
                for index in indices:
                    new_emb_vec.append(emb_vec[index])
                    new_labels.append(labels[index])
            

    y_counts, y_Xs, y_indices  = get_statce_stats(new_emb_vec + emb_vec, new_labels + labels)        
    

    return  new_emb_vec + emb_vec, new_labels + labels



def get_text(tweet):
    tweetText = re.sub(r"(?:\@|https?\://)\S+", "", tweet) # r'(?:@[\w_]+)'
    tweetText = tweetText.strip().replace('rt', '').replace('#', '').replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').replace('.', ' ').replace(',', ' ').replace('!', ' ').replace(':', ' ').replace('?', ' ?').lower()
    return tweetText

def add_to_dictionary(dictionary, key, count = 1):
    if key not in dictionary:
        dictionary[key] = count
    else:
        dictionary[key] += count
        
def add_key_value_to_dictionary(dictionary, key, value):
    if key not in dictionary:
        dictionary[key] = [value]
    else:
        dictionary[key].extend(value)

        

def get_labeled_data(text_pair_path = '../data/Contentious_pairs.csv'  , tweet_to_user_file_path = '../data/tweetid_to_users_v2.json'):        
        
    classification_data = []
    data_labels = []
    stance_to_num = {}
    # update data for labels to match with pheme
    # pheme label{'query': 0, 'comment': 1, 'deny': 3, 'support': 2}
    stance_to_num['Support'] = 2
    stance_to_num['Denial'] = 3
    stance_to_num['Comment'] = 2
    stance_to_num['Queries'] = 0

    print(stance_to_num)


    event_to_num  = {}
    event_useful_tweet_ids = {}
    useful_tweet_ids = {}
    stance_count = {}
    label_reply_ids = {}

    labeled_tweets_of_intereset = {}
    labeled_tweets_of_interest_to_user_id = {}
    with open (tweet_to_user_file_path , 'r') as f_read:
        tweetid_to_users = json.load(f_read)

        for tweetid, userid in tweetid_to_users.items():
            if str(tweetid) not in labeled_tweets_of_interest_to_user_id:
                labeled_tweets_of_interest_to_user_id[str(tweetid)] = str(userid)

    print('labeled_tweets_of_interest_to_user_id: ', len(labeled_tweets_of_interest_to_user_id))  





    df = pd.read_csv(text_pair_path, 
                     error_bad_lines=False, encoding="utf-8", 
                     dtype={"response_id":str, "target_id":str} ).fillna('')
        
        
    for response_id, target_id, response_text, target_text, stance, event, interaction_type in zip(df['response_id'], df['target_id'], 
                                                                  df['response_text'], df['target_text']
                                                                 , df['label'], df['event'], df['interaction_type']):



        if len(response_text)> 1 and len(target_text) > 1 and stance != 'Missing'   and  stance !='Queries' and  stance !='Comment' : 
            

            if response_id not in labeled_tweets_of_intereset:
                labeled_tweets_of_intereset[response_id] = 1

            if target_id not in labeled_tweets_of_intereset:
                labeled_tweets_of_intereset[target_id] = 1
            
            if stance not in stance_to_num:
                stance_to_num[stance]  = len(stance_to_num)

            if event not in event_to_num:
                event_to_num[event] = len(event_to_num)

            if event not in event_useful_tweet_ids:
                event_useful_tweet_ids[event] = {}

            if response_id not in useful_tweet_ids:
                useful_tweet_ids[response_id] = 1
            else:
                useful_tweet_ids[response_id] += 1

            if target_id not in useful_tweet_ids:
                useful_tweet_ids[target_id] = 1
            else:
                useful_tweet_ids[target_id] += 1

            add_to_dictionary(stance_count, stance_to_num[stance])

            # print('target_id', target_id, 'response_id', response_id)
            if str(target_id) in labeled_tweets_of_interest_to_user_id and  str(response_id) in labeled_tweets_of_interest_to_user_id:

                classification_data.append((target_id, response_id, labeled_tweets_of_interest_to_user_id[target_id], labeled_tweets_of_interest_to_user_id[response_id], stance_to_num[stance], event_to_num[event], interaction_type, get_text(response_text), get_text(target_text)))
                data_labels.append(stance_to_num[stance])
                add_key_value_to_dictionary(label_reply_ids, str(response_id), len(data_labels))
        
    print(len(classification_data), len(label_reply_ids))   

    print('stance_to_num: ', stance_to_num)
    print('event_to_num: ', event_to_num)
    print('labeled_tweets_of_intereset: ' , len(labeled_tweets_of_intereset))   



    shuffle(classification_data)
    balanced_classification_data, balanced_labels = balance_stance_classes(classification_data, data_labels)
    print(len(balanced_classification_data), len(classification_data))


    return classification_data, balanced_classification_data, balanced_labels, event_to_num





def get_all_events_data(classification_data, balanced_classification_data, event_to_num, interaction_type_to_print = "Reply", ):

     #"Quote" # Reply

    all_events_data = {}    

    for event_name, num in event_to_num.items():
        event_data = {}

        event_data['ids'] = []
        event_data['text'] = []
        event_data['train_ind'] = []
        event_data['val_ind'] = []
        event_data['test_ind'] = []

        event_data['info']  = []

        i = 0 
        for data_item in classification_data:
            source_id, reply_id, source_user_id, reply_user_id, stance_num, event_num, interaction_type, response_text, target_text = data_item

            if interaction_type_to_print == interaction_type or interaction_type_to_print =="ALL":

                if num == event_num: # validation event
                    
#                     if not filter_comment_and_query or (filter_comment_and_query and stance_num> 1): #filter
                    event_data['test_ind'].append(i)
                    i += 1

                    event_data['ids'].append({'src': source_id, 'reply': reply_id, 'source_user_id': source_user_id, 'reply_user_id': reply_user_id})
                    event_data['text'].append({'src': target_text, 'reply': response_text})
    #                 label_vec = [0]*len(stance_to_num)
    #                 label_vec[stance_num] = stance_to_num

                    event_data['info'].append({'label':stance_num})
                    

        for data_item in balanced_classification_data:
            source_id, reply_id, source_user_id, reply_user_id, stance_num, event_num, interaction_type, response_text, target_text = data_item

            if interaction_type_to_print == interaction_type or interaction_type_to_print =="ALL":

                if num != event_num: # not validation event
#                     if not filter_comment_and_query or (filter_comment_and_query and stance_num> 1): #filter                    
                    event_data['train_ind'].append(i )            
                    i += 1

                    event_data['ids'].append({'src': source_id, 'reply': reply_id, 'source_user_id': source_user_id, 'reply_user_id': reply_user_id})
                    event_data['text'].append({'src': target_text, 'reply': response_text})
    #                 label_vec = [0]*len(stance_to_num)
    #                 label_vec[stance_num] = stance_to_num

                    event_data['info'].append({'label':stance_num})

        all_events_data[event_name] = event_data
        
    return all_events_data


        
def get_accuracy_estimate(truths, predicted):

    print(classification_report(truths, predicted))
    print(' TEXT Classifier Accuracy: ', accuracy_score(truths, predicted))

    print('f1_score micro: ', f1_score(truths, predicted, average='micro'))
    print('f1_score macro: ', f1_score(truths, predicted, average='macro'))    
    print('f1_score wieghted: ', f1_score(truths, predicted, average='weighted'))        

    return f1_score(truths, predicted, average='micro'), f1_score(truths, predicted, average='macro'), f1_score(truths, predicted, average='weighted')


    

def get_text_classifier_prdictions(all_events_data_reply):    

    classifier = ('svm12', Pipeline([('vect', CountVectorizer()),
                                                 ('tfidf', TfidfTransformer()),
                                                 ('clf-svm', SGDClassifier(loss='hinge', penalty='l2',
                                                                           alpha=1e-3, max_iter=15, random_state=42)),
                                                ])
                                            , {'vect__ngram_range': [(1, 1), (1, 2)], 
                                              'tfidf__use_idf': (True, False),
                                              'clf-svm__alpha': (1e-2, 1e-3),
                                             })

    results = {}
    svm_event_score = {}
    outputs = {}
    for i in range(1):
        for data_name, all_events_data in [
    #                                     ('all', all_events_data_all),
    #                                        ('quote', all_events_data_quote),
                                           ('reply', all_events_data_reply)
                                          ]:  

        #     all_events_data = get_all_events_data(interaction_type_to_print = interaction_type_to_print)

            one_type_result = {}
            for event_name, all_event_data in all_events_data.items():
                if True: #event_name == 'Iran_Deal': # Student_Marches
                    print(event_name, len(all_event_data['train_ind']), len(all_event_data['test_ind']))

                    train_replies = []
                    train_labels = []
                    for train_index in all_event_data['train_ind']:
                        train_replies.append(all_event_data['text'][train_index]['reply'])
                        train_labels.append(all_event_data['info'][train_index]['label'])

                    test_replies = []
                    test_labels = []
                    test_source_reply_user_ids  = []
                    for test_index in all_event_data['test_ind']:
                        test_replies.append(all_event_data['text'][test_index]['reply'])
                        test_labels.append(all_event_data['info'][test_index]['label'])
                        test_source_reply_user_ids.append((all_event_data['ids'][test_index]['source_user_id'] , all_event_data['ids'][test_index]['reply_user_id'] ))


                    print(len(train_replies), len(train_labels), len(test_replies), len(test_labels)) 


                    clf_name, text_clf, __  = classifier

                    text_clf.fit(train_replies,  train_labels)

                    predicted = text_clf.predict(test_replies)
                    truths = test_labels

                    f1_micro, f1_macro,  f1_weighted = get_accuracy_estimate(truths, predicted)

                    print('data_name', data_name , 'event_name ', event_name , ' clf_name: ', clf_name, 'f1: ', f1_micro)

#                     one_type_result[event_name] = f1

                    one_type_result[event_name] = {'f1_micro': f1_micro,
                                                   'f1_macro': f1_macro,
                                                   'f1_weighted': f1_weighted,
                                                   'y_truths': ' '.join([str(i) for i in truths]), 
                                                   'y_classes': ' '.join([str(i) for i in predicted])}
    
                    svm_event_score[event_name] = f1_macro    

                    outputs[event_name] = (predicted, truths, test_source_reply_user_ids)

        #     print(data_name, ' Mean: ', np.mean(list(one_type_result.values())))
            results[data_name + '_' + str(i)]= one_type_result  


    return outputs







