
from stance_processor.data_processing_helpers import *
from stance_processor.StanceMatricesHelper import *
from stance_processor.TextDataHandler import *
from stance_processor.TextClassifier import *
from stance_processor.data_loader import *
from stance_processor.save_output import *

from sklearn.preprocessing import normalize


## Propogate labels for a few user to other users
def propagate_label_with_confidence2(matrix_from, # a numpy vector
                                     matrix_from_confidence, # a numpy vector
                                    weight_matrix, # a numpy matrix
                                    use_confidence = False):
    
    threshold = 0
    if use_confidence:
        matrix_to = np.dot(weight_matrix, np.multiply(matrix_from, matrix_from_confidence))
    else:
#         matrix_from = np.multiply(matrix_from, matrix_from_confidence) # new test
        normalized_pro_matrx = np.where(matrix_from > threshold, 1.0/np.sum(np.abs(matrix_from[matrix_from > threshold])), 0)
        normalized_con_matrx = np.where(matrix_from < threshold, -1.0/np.sum(np.abs(matrix_from[matrix_from < threshold])), 0)

        normalized_from_matrx = normalized_pro_matrx +  normalized_con_matrx
        
        matrix_to = np.dot(weight_matrix, normalized_from_matrx)



    binarize_matrix2(matrix_to)

    if use_confidence:
        matrix_to_positive = np.dot(weight_matrix,  np.multiply(np.where(matrix_from > threshold, 1, 0),
                                                                matrix_from_confidence))

        matrix_to_negative = np.dot(weight_matrix,  np.multiply(np.where(matrix_from < threshold, 1, 0),
                                                                matrix_from_confidence))
    else:
        matrix_to_positive = np.dot(weight_matrix,  np.where(matrix_from > threshold, 1, 0))

        matrix_to_negative = np.dot(weight_matrix,  np.where(matrix_from < threshold, 1, 0))

        

    denom = (matrix_to_positive + matrix_to_negative)
    denom[denom ==0] = 1 # denom 0 gives error.. can we have a different number?
    matrix_to_confidece  = np.abs(np.divide((matrix_to_positive - matrix_to_negative),  denom))

    return matrix_to, matrix_to_confidece


## Use the labeled hashtags to get a set of labeled seed users
def get_stance_vactors_from_seed_tags(seed_tag_labels, # a dictionary of hashtags with stance lables
                                      tweet_user_index, # a dictionary of user to an index, See data_processing_helpers.py line 131, tweet_user_index[user] = tweet_user_index_length
                                      hashtag_index, # a dictionary of hashtg to an index, like above
                                      user_hashtag_weighted_matrix,  # a matrix indicating the count of usage of a hashtag by a user, See data_processing_helpers.py line 147,  user_hashtag_weighted_matrix, hashtag_index, index_to_tag = create_vector(user_hashtag_count
                                      N_TOP = 250): # The count of (top) hashtags to use

    
    user_stance_matrix, hashtag_stance_matrix =  StanceMatricesHelper.get_initialized_stance_matrices(tweet_user_index, N_TOP)
    StanceMatricesHelper.set_intial_tag_labels(hashtag_stance_matrix, 
                                               seed_tag_labels, 
                                               hashtag_index)

    hashtag_stance_matrix_confidence = np.where( hashtag_stance_matrix != 0, 1, 0)

    user_stance_matrix, user_stance_matrix_confidence = StanceMatricesHelper.propagate_label_with_confidence(
                                                                         hashtag_stance_matrix,
                                                                          hashtag_stance_matrix_confidence,
                                                                          user_hashtag_weighted_matrix)

    return user_stance_matrix, user_stance_matrix_confidence, hashtag_stance_matrix, hashtag_stance_matrix_confidence 


# change non integers (decimals) to integers
def binarize_matrix2(user_label_matrix # a numpy matirx or a numpy vector
                    ):
    for i in range(0, len(user_label_matrix)):
        if user_label_matrix[i] > 0:
            user_label_matrix[i] = 1
        elif user_label_matrix[i] < 0:
            user_label_matrix[i] = -1

    return user_label_matrix

    
# Takes users   users stance matrix as input, run the label propagation algorithm and returns a new user stance matrix
# Read the paper to know more about the label propagation
def get_matrix_based_propogation_result(processJson, # It's an object with many variables in it. It is used to get the accuracy estimate.
                                        tweet_user_index, # a dictionary of user to an index, See data_processing_helpers.py line 131, tweet_user_index[user] = tweet_user_index_length
                                        user_stance_matrix, # users stance numpy vector 
                                        user_stance_matrix_confidence, # Confidence in predicting users stance -- a  numpy vector 
                                       user_retweet_weighted_matrix, # a weighted matrix representing the user retweets graph
                                       user_hashtag_weighted_matrix, # a weighted matrix representing the user hashtag graph
                                       is_debug = False, # Print debug messages
                                       inner_iteration_count= 1, # How many inner iterations on label propagation to run
                                        filter_low_confidence_properties = True, # A boolean 
                                        property_confidence_threshold  = 0.7,  # Decimal
                                       retweet_only_for_propagation  = False, # Boolean indicating if only reweets are used for label propagation
                                       hashtag_only_for_propagation = False): # Boolean indicating if only hashtags are used for label propagation
            

    if is_debug:
        print('Intial from hashtag, user_stance_matrix')
        acc0, acc_without_unlabled_users, random_fraction\
            = StanceMatricesHelper.get_accuracy_estimate(processJson.user_label, 
                                                       user_stance_matrix,
                                                       tweet_user_index)


    if retweet_only_for_propagation:
        joint_property_matrix = user_retweet_weighted_matrix
    elif hashtag_only_for_propagation:
        joint_property_matrix = user_hashtag_weighted_matrix
    else:
        joint_property_matrix = np.concatenate((user_retweet_weighted_matrix, user_hashtag_weighted_matrix), axis=1) 
    
    
    user_stance_matrix1, user_stance_matrix_confidence1 = user_tag_propogator2(
                                                             user_stance_matrix,
                                                              user_stance_matrix_confidence,
                                                              joint_property_matrix,
                                                            inner_iter_count = inner_iteration_count,
                                                             filter_low_confidence_properties = filter_low_confidence_properties,
                                                             property_confidence_threshold  = property_confidence_threshold)

    if is_debug:
        print('user_stance_matrix_confidence1:', np.sum(np.abs(user_stance_matrix_confidence1)))

        print('Joint based propogation, user_stance_matrix1')
        acc0, acc_without_unlabled_users, random_fraction\
            = StanceMatricesHelper.get_accuracy_estimate(processJson.user_label, 
                                                       user_stance_matrix1,
                                                       tweet_user_index)



    return user_stance_matrix1, user_stance_matrix_confidence1
    


# This is bi-partitie label propagation
# It propagates stance from labeled users to additional users     
def user_tag_propogator2(user_stance_matrix,  # A numpy vector indicating stance
                            user_stance_matrix_confidence, # A numpy vector indicating confidenc in predicting stance
                            user_property_weighted_matrix, # A numpy matrix indicting user-hashtag (or user-retweet) graph
                            inner_iter_count = 3, # an integer
                            filter_low_confidence_properties = True, # a boolean
                            property_confidence_threshold = 0.5): # a decimal threshold

        proposed_user_stance_matrix_tag = np.copy(user_stance_matrix)
        proposed_user_stance_matrix_tag_confidence = np.copy(user_stance_matrix_confidence)
        
        for k in range(0, inner_iter_count): # iterate 3 times
            
            proposed_user_stance_matrix_tag, proposed_user_stance_matrix_tag_confidence = \
                propgate_labels_via_tags_once(proposed_user_stance_matrix_tag,
                                                proposed_user_stance_matrix_tag_confidence,
                                                user_property_weighted_matrix,
                                                filter_low_confidence_properties ,
                                                property_confidence_threshold )

        return proposed_user_stance_matrix_tag, proposed_user_stance_matrix_tag_confidence  
    
    
    
# This is one step of bi-partitie label propagation
# It propagates stance from users to tags and then tags to users (only once)
def propgate_labels_via_tags_once(user_stance_matrix, # a numpy vector
                                  user_stance_matrix_confidence,  # a numpy vector
                                  user_hashtag_weighted_matrix, # a numpy matrix
                                 filter_low_confidence_properties, # a boolean indicating if thresholding is needed
                                 property_confidence_threshold): # a decimal indicating the threshold
        
    hashtag_stance_matrix, hashtag_stance_matrix_confidence = propagate_label_with_confidence2(user_stance_matrix, 
                                                                 user_stance_matrix_confidence,
                                                                np.transpose(user_hashtag_weighted_matrix))

    
    if filter_low_confidence_properties:
        hashtag_stance_matrix, hashtag_stance_matrix_confidence = filter_confident_examples(hashtag_stance_matrix, 
                                                      hashtag_stance_matrix_confidence,
                                                      filter_threshold = property_confidence_threshold)
    
    
    user_stance_matrix, user_stance_matrix_confidence = propagate_label_with_confidence2(hashtag_stance_matrix,
                                                              hashtag_stance_matrix_confidence,
                                                              user_hashtag_weighted_matrix)


    return user_stance_matrix, user_stance_matrix_confidence    

## Code for the text based user stance classifier
## It uses the labled users in user_stance_matrix to train a text classifier
## The text classifier is then used to lablel other text (form tweets)
## The labled texts are then used to get a labeles for users
## Check the file TextClassifier.py for details

def update_stance_matrix_using_text(user_stance_matrix, # a numpy vector
                                   user_stance_matrix_confidence, # a numpy vector
                                   text_classifier, # a SVM based text classifier
                                   text_filter_threshold = 0.51, # a threshold to not use less confident examples
                                   text_clf_svm = None, #  the SVM text classifier
                                   parameters_svm = None): # Parameters of the the SVM text classifier
    
    filtered_user_stance_matrix, filtered_user_stance_matrix_confidence = filter_confident_examples(user_stance_matrix, 
                              user_stance_matrix_confidence,
                              filter_threshold = text_filter_threshold)
    
    
    if text_clf_svm == None or parameters_svm == None:
        text_clf_svm = text_classifier.train_model2(filtered_user_stance_matrix)
        
    else:
        text_clf_svm = text_classifier.train_model2(filtered_user_stance_matrix, 
                                                    text_clf_svm,
                                                    parameters_svm)
    
    
    
    __, __, proposed_user_stance_matrix_text, proposed_user_stance_matrix_text_confidence\
            = text_classifier.update_users_using_text_classifier(text_clf_svm, 
                                                                user_stance_matrix)
       

    return proposed_user_stance_matrix_text, proposed_user_stance_matrix_text_confidence

## Code to filter less confident examples. mostly straightforward
def filter_confident_examples(user_stance_matrix, # a numpy vector
                              user_stance_matrix_confidence, # a numpy vector
                              filter_threshold = 0.7):
    
    filtered_user_stance_matrix = np.zeros((np.shape(user_stance_matrix)[0], 1))
    filtered_user_stance_matrix_confidence = np.zeros((np.shape(user_stance_matrix)[0], 1))
    
    for i in range(0, np.shape(user_stance_matrix)[0]):
        for j in range(0, np.shape(user_stance_matrix)[1]):
            if user_stance_matrix_confidence[i, j] > filter_threshold:
                filtered_user_stance_matrix[i, j] = user_stance_matrix[i, j]
                filtered_user_stance_matrix_confidence[i, j] = user_stance_matrix_confidence[i, j]


    return filtered_user_stance_matrix, filtered_user_stance_matrix_confidence


def combine_matrices(first_matrix, # a numpy matrix
                        second_matrix): # a numpy matrix

    first_matrix = np.copy(first_matrix)

    for i in range(0, len(first_matrix)):
        if first_matrix[i] == 0:
            first_matrix[i] = second_matrix[i]
            
    return first_matrix



# Update zero values in the first matrix to non zero values for the second matrix
def update_first_matrix(first_matrix, # a numpy matrix
                        second_matrix): # a numpy matrix
    for i in range(0, len(first_matrix)):
        if first_matrix[i] == 0:
            first_matrix[i] = second_matrix[i]
            
    return first_matrix


# Update first matrix values to the second matrix if the second matrix values are of lower confidence
def update_first_matrix_with_more_confident_labels(first_matrix, #a numpy vector
                                                   first_matrix_conf, #a numpy vector
                                                   second_matrix, #a numpy vector
                                                   second_matrix_conf, #a numpy vector
                                                    confidence_trheshold = 0.7, # decimal threshold
                                                   percent = 0.05): # percent of stance lables to update                                                   
    
    print('np shape:', np.shape(first_matrix_conf))
    
    first_matrix_conf_norm = normalize(first_matrix_conf, axis=0).ravel()
    second_matrix_conf_norm = normalize(second_matrix_conf, axis=0).ravel()
    
    users_updated = 0
    for i in range(0, len(first_matrix)):
        if first_matrix_conf_norm[i] < second_matrix_conf_norm[i]:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            users_updated += 1
            
    return first_matrix, first_matrix_conf, users_updated, 0


def combine_matrices_with_more_confident_labels(first_matrix, #a numpy vector
                                                   first_matrix_conf, #a numpy vector
                                                   second_matrix, #a numpy vector
                                                   second_matrix_conf): #a numpy vector
    
    print('np shape:', np.shape(first_matrix_conf))

    first_matrix = np.copy(first_matrix)
    first_matrix_conf = np.copy(first_matrix_conf)

    
    first_matrix_conf_norm = normalize(first_matrix_conf, axis=0).ravel()
    second_matrix_conf_norm = normalize(second_matrix_conf, axis=0).ravel()
    
    users_updated = 0
    for i in range(0, len(first_matrix)):
        if first_matrix_conf_norm[i] < second_matrix_conf_norm[i]:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            users_updated += 1
            
    return first_matrix, first_matrix_conf, users_updated

            
def update_first_matrix_with_more_confident_labels_v2(first_matrix, #a numpy vector
                                                   first_matrix_conf, #a numpy vector
                                                   second_matrix, #a numpy vector
                                                   second_matrix_conf, #a numpy vector
                                                   confidence_trheshold = 0.7, # decimal threshold
                                                   percent = 0.05): # percent of stance lables to update
    
    print('np shape:', np.shape(first_matrix_conf))
    
    first_matrix_conf_norm = normalize(first_matrix_conf, axis=0).ravel()
    second_matrix_conf_norm = normalize(second_matrix_conf, axis=0).ravel()
    
    users_updated = 0
    new_users_labeled = 0 
    for i in range(0, len(first_matrix)):
        if first_matrix[i] != 0 and first_matrix_conf_norm[i] < second_matrix_conf_norm[i]:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            users_updated += 1
        elif first_matrix[i] == 0:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            new_users_labeled += 1
            
    return first_matrix, first_matrix_conf, users_updated, new_users_labeled


def combine_matrices_with_more_confident_labels_v2(first_matrix, #a numpy vector
                                                   first_matrix_conf, #a numpy vector
                                                   second_matrix, #a numpy vector
                                                   second_matrix_conf): #a numpy vector
    
    print('np shape:', np.shape(first_matrix_conf))

    first_matrix = np.copy(first_matrix)
    first_matrix_conf = np.copy(first_matrix_conf)

    
    first_matrix_conf_norm = normalize(first_matrix_conf, axis=0).ravel()
    second_matrix_conf_norm = normalize(second_matrix_conf, axis=0).ravel()
    
    users_updated = 0
    for i in range(0, len(first_matrix)):
        if first_matrix[i] != 0 and first_matrix_conf_norm[i] < second_matrix_conf_norm[i]:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            users_updated += 1
        elif first_matrix[i] == 0:
            first_matrix[i] = second_matrix[i]
            first_matrix_conf[i] = second_matrix_conf[i]
            users_updated += 1
            
    return first_matrix, first_matrix_conf, users_updated


## Code to exchange labels of the two classifiers
def update_first_matrix_with_more_confident_labels_v3(user_stance_matrix, # a numpy vector representing users' stance
                                             user_stance_matrix_confidence, # a numpy vector representing confidence in users' stance
                                            proposed_user_stance_matrix, # a numpy vector representing another users stance (from another classifier)
                                             proposed_user_stance_matrix_confidence, # a numpy vector representing confidence in another users stance (from another classifier)
                                            confidence_trheshold = 0.7, # decimal threshold
                                            percent = 0.05): # percent of stance lables to update
    
    
    filtered_proposed_user_stance_matrix, filtered_proposed_user_stance_matrix_confidence =\
                filter_confident_examples(proposed_user_stance_matrix, 
                                          proposed_user_stance_matrix_confidence, 
                                          confidence_trheshold)   
        
    user_stance_matrix_confidence_norm = normalize(user_stance_matrix_confidence, axis=0).ravel()
    filtered_proposed_user_stance_matrix_confidence_norm = normalize(filtered_proposed_user_stance_matrix_confidence, axis=0).ravel()

    
    labels_count = len(user_stance_matrix) # np.sum(np.abs(user_stance_matrix))
    conf_sorted = np.argsort(filtered_proposed_user_stance_matrix_confidence_norm,  axis=0)        
        
    users_updated = 0   
    new_users_labeled = 0       
    for i  in conf_sorted[::-1]:
        proposed_confidence = filtered_proposed_user_stance_matrix_confidence_norm[i]
        confidence = user_stance_matrix_confidence_norm[i]
        
        
        if user_stance_matrix[i] != 0 and proposed_user_stance_matrix[i] != 0 and proposed_confidence > confidence  and users_updated < int(labels_count*percent):
#             if user_stance_matrix[i] != proposed_user_stance_matrix[i]:
            user_stance_matrix[i] = filtered_proposed_user_stance_matrix[i]
            user_stance_matrix_confidence[i] = filtered_proposed_user_stance_matrix_confidence[i]
          
            users_updated += 1
            
        elif user_stance_matrix[i] == 0  and proposed_user_stance_matrix[i] != 0  and new_users_labeled < int(labels_count*percent): # and proposed_confidence > confidence_trheshold: # 
            user_stance_matrix[i] = filtered_proposed_user_stance_matrix[i]
            user_stance_matrix_confidence[i] = filtered_proposed_user_stance_matrix_confidence[i]
            
            new_users_labeled += 1
            
        
    print('add_top_k_labeled_percent_users_to_stance_matrix', 'Number of users_updated: ', users_updated,  ' max possible update:', int(labels_count*percent))       
    print('Number of users updated: ', users_updated)   
    print('new_users_labeled: ', new_users_labeled)      
    
        
    return user_stance_matrix, user_stance_matrix_confidence, users_updated, new_users_labeled



def update_first_matrix_with_more_confident_labels_from_second_matrix_where_third_matrix_is_unlabeled(user_seeed_stance_matrix, # a numpy vector representing users' stance
                                              user_seeed_stance_matrix_conf, # a numpy vector representing confidence in users' stance
                                              user_stance_matrix, # a numpy vector representing users' stance
                                             user_stance_matrix_confidence, # a numpy vector representing confidence in users' stance
                                            proposed_user_stance_matrix, # a numpy vector representing another users stance (from another classifier)
                                             proposed_user_stance_matrix_confidence, # a numpy vector representing confidence in another users stance (from another classifier)
                                            confidence_trheshold = 0.7, # decimal threshold
                                            percent = 0.05): # percent of stance lables to update
    
    
    filtered_proposed_user_stance_matrix, filtered_proposed_user_stance_matrix_confidence =\
                filter_confident_examples(proposed_user_stance_matrix, 
                                          proposed_user_stance_matrix_confidence, 
                                          confidence_trheshold)   
        
    user_stance_matrix_confidence_norm = normalize(user_stance_matrix_confidence, axis=0).ravel()
    filtered_proposed_user_stance_matrix_confidence_norm = normalize(filtered_proposed_user_stance_matrix_confidence, axis=0).ravel()

    
    labels_count = len(user_stance_matrix) # np.sum(np.abs(user_stance_matrix))
    conf_sorted = np.argsort(filtered_proposed_user_stance_matrix_confidence_norm,  axis=0)        
        
    users_updated = 0   
    new_users_labeled = 0       
    for i  in conf_sorted[::-1]:
        proposed_confidence = filtered_proposed_user_stance_matrix_confidence_norm[i]
        confidence = user_stance_matrix_confidence_norm[i]
        
        
        if user_seeed_stance_matrix[i] == 0 and user_stance_matrix[i] != 0 and proposed_user_stance_matrix[i] != 0 and proposed_confidence > confidence  and users_updated < int(labels_count*percent):
#             if user_stance_matrix[i] != proposed_user_stance_matrix[i]:
            user_seeed_stance_matrix[i] = filtered_proposed_user_stance_matrix[i]
            user_seeed_stance_matrix_conf[i] = filtered_proposed_user_stance_matrix_confidence[i]
          
            users_updated += 1
            
        elif user_seeed_stance_matrix[i] == 0 and user_stance_matrix[i] == 0  and proposed_user_stance_matrix[i] != 0  and new_users_labeled < int(labels_count*percent): # and proposed_confidence > confidence_trheshold: # 
            user_seeed_stance_matrix[i] = filtered_proposed_user_stance_matrix[i]
            user_seeed_stance_matrix_conf[i] = filtered_proposed_user_stance_matrix_confidence[i]
            
            new_users_labeled += 1
            
        
    print('add_top_k_labeled_percent_users_to_stance_matrix', 'Number of users_updated: ', users_updated,  ' max possible update:', int(labels_count*percent))       
    print('Number of users updated: ', users_updated)   
    print('new_users_labeled: ', new_users_labeled)      
    
        
    return user_seeed_stance_matrix, user_seeed_stance_matrix_conf, users_updated, new_users_labeled


def run_cotrain_experiments(args):
    
    experiment_type = args['experiment_type']
    text_threshold = args['text_threshold']
    binarize = args['binarize']
    count_of_retweet_to_consider = args['retweet_count']
    count_of_hgashtag_to_consider = args['hashtag_count']
    inner_iteration_count = args['inner_iteration_count'] 
    iteration_count = args['iteration_count']    
    property_confidence_threshold = args['property_confidence_threshold']
    classifier_name = args['name']
    text_clf_svm = args['clf']
    parameters_svm = args['parameters']
    property_type = args['property_type']
    dataJson = args['dataJson']
    seed_tag_labels = args['seed_tag_labels']
    confidence_threshold_for_mixing = args['confidence_threshold_for_mixing']
    mixing_percent = args['mixing_percent']
    results_path = args['results_path']


    if property_type == 0:
        hashtag_only_for_propagation = True
        retweet_only_for_propagation = False
    elif property_type == 1:
        retweet_only_for_propagation = True
        hashtag_only_for_propagation = False
    else:
        hashtag_only_for_propagation = False
        retweet_only_for_propagation = False

    # Declare local variables
    threshold = 1.0
    final_accuray = 0
    total_labeled_users_count = 0
    k =1

    # Create all data structures needed for the experiment
    hashtag_index, index_to_tag, tweet_user_index, users_index_to_id, user_retweet_weighted_matrix, user_hashtag_weighted_matrix =\
    initialize_vectors(dataJson.user_tweet_count,
               dataJson.user_retweet_count, 
               dataJson.user_endtag_count, 
               count_of_hgashtag_to_consider,
               count_of_retweet_to_consider,
               binarize_count = binarize)       

#     print('tweet_user_index: ', tweet_user_index['1516063496'])
    
    # Create a text classifier that is used later for training and predictign using text data
    dataHandler = TextDataHandler(dataJson.users_text, dataJson.endtags_text)
    text_classifier = TextClassifier(tweet_user_index, users_index_to_id, dataHandler)   


    # Using initial labeled seed hashtags, get users stance vector and hashtag stance vector
    user_stance_matrix, user_stance_matrix_confidence, hashtag_stance_matrix, hashtag_stance_matrix_confidence \
        = get_stance_vactors_from_seed_tags(seed_tag_labels,
                                              tweet_user_index, 
                                              hashtag_index,
                                              user_hashtag_weighted_matrix,
                                            count_of_hgashtag_to_consider)    

    
    print('Initial Labeled users count: ', np.sum(np.abs(user_stance_matrix)), len(np.where(user_stance_matrix > 0)[0]), len(np.where(user_stance_matrix < 0)[0]))    

    for inner_iter in range(0, iteration_count):
        ## Network based classification below
        # Using initial labeled users, propogate the lables to other users
        user_stance_matrix_network, user_stance_matrix_network_confidence = \
                get_matrix_based_propogation_result(dataJson, 
                                                    tweet_user_index, 
                                                    user_stance_matrix,
                                                    user_stance_matrix_confidence,
                                                    user_retweet_weighted_matrix,
                                                    user_hashtag_weighted_matrix,
                                                    inner_iteration_count = inner_iteration_count,
                                                    filter_low_confidence_properties = True,
                                                    property_confidence_threshold  = property_confidence_threshold,
                                                    hashtag_only_for_propagation = hashtag_only_for_propagation,
                                                    retweet_only_for_propagation = retweet_only_for_propagation)


        print( 'Network Labeled users count: ', np.sum(np.abs(user_stance_matrix_network)), len(np.where(user_stance_matrix_network > 0)[0]), len(np.where(user_stance_matrix_network < 0)[0]))

#         if len(dataJson.user_label) > 0:
        print('\n Network classifier accuracy ')        
        acc_network, acc_without_unlabled_users_network, random_fraction_network\
                = StanceMatricesHelper.get_accuracy_estimate(dataJson.user_label, 
                                                           user_stance_matrix_network,
                                                           tweet_user_index)



        # Text classification now    
        # Using labeled users, label all users based on text
        print('\n Text classification now ')

#         text_threshold = text_threshold + 0.05
        user_stance_matrix_text, user_stance_matrix_confidence_text = update_stance_matrix_using_text(
                                           user_stance_matrix_network, 
                                           user_stance_matrix_network_confidence,
                                           text_classifier,
                                            text_filter_threshold = text_threshold,
                                           text_clf_svm = text_clf_svm, 
                                           parameters_svm =  parameters_svm)  


        # If predicted stance is not an integer, convert it to integer    
        user_stance_matrix_text = binarize_matrix2(user_stance_matrix_text)
        print( 'Text based Labeled users count: ', np.sum(np.abs(user_stance_matrix_text)), len(np.where(user_stance_matrix_text > 0)[0]), len(np.where(user_stance_matrix_text < 0)[0]))


#         if len(dataJson.user_label) > 0:
        print('\n Text classifier  ')        
        acc_text, acc_without_unlabled_users_text, random_fraction_text\
                = StanceMatricesHelper.get_accuracy_estimate(dataJson.user_label, 
                                                           user_stance_matrix_text,
                                                           tweet_user_index)



        # Joint model uses the prediction of both the models to make a better prediction using confidence
        # joint_stance_matrix, joint_stance_matrix_conf, users_updated, new_users_labeled = update_first_matrix_with_more_confident_labels_v3(user_stance_matrix_network, 
        #                                                                      user_stance_matrix_network_confidence, 
        #                                                                       user_stance_matrix_text, 
        #                                                                      user_stance_matrix_confidence_text,
        #                                                                      confidence_trheshold = confidence_threshold_for_mixing, 
        #                                                                       percent = mixing_percent)     



        joint_stance_matrix, joint_stance_matrix_conf, users_updated, new_users_labeled = update_first_matrix_with_more_confident_labels_from_second_matrix_where_third_matrix_is_unlabeled(
                                                                              user_stance_matrix, 
                                                                              user_stance_matrix_confidence,
                                                                              user_stance_matrix_network, 
                                                                              user_stance_matrix_network_confidence, 
                                                                              user_stance_matrix_text, 
                                                                              user_stance_matrix_confidence_text,
                                                                              confidence_trheshold = confidence_threshold_for_mixing, 
                                                                              percent = mixing_percent)     


        print( 'Joint  Labeled users count: ', np.sum(np.abs(joint_stance_matrix)), len(np.where(joint_stance_matrix > 0)[0]), len(np.where(joint_stance_matrix < 0)[0]))

        user_stance_matrix = joint_stance_matrix #user_stance_matrix_network
        user_stance_matrix_confidence = joint_stance_matrix_conf #user_stance_matrix_network_confidence




        combined_stance_matrix, combined_stance_matrix_conf, __ = combine_matrices_with_more_confident_labels_v2(user_stance_matrix_network, 
                                                                             user_stance_matrix_network_confidence, 
                                                                              user_stance_matrix_text, 
                                                                             user_stance_matrix_confidence_text)       


#         if len(dataJson.user_label) > 0:
        print('\n Joint accuracy for iteration : ', inner_iter )
        final_accuray, acc_without_unlabled_users, random_fraction\
            = StanceMatricesHelper.get_accuracy_estimate(dataJson.user_label, 
                                                       combined_stance_matrix,
                                                       tweet_user_index)



    
#     stance_vector_to_user_label(user_stance_matrix, 
#                                 users_index_to_id, 
#                                 experiment_type + '_joint_result_iter2.csv')
        if len(dataJson.user_label) > 0:

            with open('./results/final_result_summary_' +experiment_type +  '.csv', 'a') as f_result_write:
                f_result_write.write("experiment_type v3:{},inner_iter:{}, final_Accuracy:{},{},{},text_accuracy:{},{},{},network_accuracy:{},{},{}, users_updated:{}, newly_lebeld_users:{}\n".format(experiment_type,
                                                                                                                                                     inner_iter,
                                                                                                                                                     final_accuray, acc_without_unlabled_users, random_fraction, 
                                                                                                                                                     acc_text, acc_without_unlabled_users_text, random_fraction_text,
                                                                                                                                                     acc_network, acc_without_unlabled_users_network, random_fraction_network,
                                                                                                                                                     users_updated,
                                                                                                                                                     new_users_labeled))  
    
    print(' Final accuracy: ',  final_accuray, random_fraction, acc_without_unlabled_users)

#         if  k >= iteration_count -1: #  or random_fraction < 0.02 or
    final_acc_formated = "{:0.2f}".format(final_accuray)
#                         threshold_decrease_ratio_formated = "{:0.2f}".format(threshold_decrease_ratio_orig)

#     print(' Done with labeleing all users: ', final_acc_formated)


    print(experiment_type, 'final_Accuracy: ', final_acc_formated, 'text_accuracy ', acc_text,'network_accuracy: ',  acc_network)  
    
#     return user_stance_matrix, user_stance_matrix_confidence


    # stance_matrix_to_be_used_for_output = combined_stance_matrix
    # stance_matrix_conf_to_be_used_for_output    = combined_stance_matrix_conf

    predicted_user_stance = write_stance_output(combined_stance_matrix, 
                        combined_stance_matrix_conf,
                        dataJson.user_tweet_count,
                        users_index_to_id, 
                        experiment_type + '_' + str(inner_iter)+ '_user_stance.csv',
                        first_column_name  = 'userId',
                        results_path = results_path)
    
    
    
    ## now get stance for hashtags
    hashtag_stance_matrix, hashtag_stance_matrix_confidence = propagate_label_with_confidence2(user_stance_matrix, 
                                                             user_stance_matrix_confidence,
                                                            np.transpose(user_hashtag_weighted_matrix),
                                                            use_confidence = False)

    
    
    write_stance_output(hashtag_stance_matrix, 
                        hashtag_stance_matrix_confidence,
                        dataJson.user_endtag_count,
                        index_to_tag, 
                        experiment_type + '_' + str(inner_iter) + '_hashtag_stance.csv',
                        first_column_name  = 'hashtag',
                        results_path = results_path)
    
        
    
    user_url_weighted_matrix, url_index, index_to_url = create_vector(dataJson.user_url_count, 
                                                                      tweet_user_index, 
                                                                      500,
                                                                      False)

                
    
    url_stance, url_stance_confidence = propagate_label_with_confidence2(user_stance_matrix, 
                                                             user_stance_matrix_confidence,
                                                            np.transpose(user_url_weighted_matrix),
                                                            use_confidence = False)


    write_stance_output(url_stance, 
                        url_stance_confidence,
                        dataJson.user_url_count,
                        index_to_url, 
                        experiment_type + '_' + str(inner_iter) + '_url_stance.csv',
                        first_column_name  = 'url',
                        results_path = results_path)



    user_media_url_weighted_matrix, media_url_index, index_to_media_url = create_vector(dataJson.user_media_url_count, 
                                                                      tweet_user_index, 
                                                                      500,
                                                                      False)

                
    
    media_url_stance, media_url_stance_confidence = propagate_label_with_confidence2(user_stance_matrix, 
                                                             user_stance_matrix_confidence,
                                                            np.transpose(user_media_url_weighted_matrix),
                                                            use_confidence = False)


    write_stance_output(media_url_stance, 
                        media_url_stance_confidence,
                        dataJson.user_media_url_count,
                        index_to_media_url, 
                        experiment_type + '_' + str(inner_iter) + '_media_url_stance.csv',
                        first_column_name  = 'media_url',
                        results_path = results_path)


    return predicted_user_stance


    
    



