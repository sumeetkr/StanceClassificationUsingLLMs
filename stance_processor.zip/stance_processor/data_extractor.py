
import json
import os
import re
import sys
import os.path as path
from stance_processor.data_processing_helpers import * 
                                    
class Data():
    def __init__(self, user_tweet_count, user_retweet_count, user_endtag_count, user_replies_count,
                user_url_count, users_text, endtags_text, hashtag_text, user_label, user_media_url_count = None, reply_data = None):

        self.user_tweet_count = user_tweet_count
        self.user_retweet_count = user_retweet_count
        self.user_endtag_count = user_endtag_count
        self.user_replies_count = user_replies_count
        self.user_url_count = user_url_count        
        self.users_text = users_text
        self.endtags_text = endtags_text
        self.hashtag_text = hashtag_text
        self.user_label = user_label
        self.user_media_url_count = user_media_url_count
        self.reply_data = reply_data



class DataTablesExtractor():

    @staticmethod
    def extract_labels(label_file_path):
        user_label = {}
        try:
            with open(label_file_path) as f_read:
                for line in f_read:
                    data_dict = json.loads(line)

                    userId = str(data_dict['user'])
                    stance = data_dict['bias']

                    if userId in user_label:
                        print('duplicate: ', userId)


                    if not isinstance(stance, int):
                        stance = int(stance)

                    if stance == 2:
                        stance = 1
                    elif stance == -2 :
                        stance = -1

                    user_label[userId] = stance

        except:
            print(' Some error, may be no labeled examples')
                
        return user_label

    @staticmethod
    def extract_text_hashtags(text, 
                              user_text,
                              endtags_text, 
                              hashtag_text,
                             include_retweet = True):

        alltags, end_tags, endtag_free_text = TextProcessingHelpers.get_hashtagsall_and_at_the_end_of_sentence(text)

        for tag in end_tags:
            if tag not in endtags_text:
                endtags_text[tag] = []
                
            endtags_text[tag].append(endtag_free_text)

        for tag in alltags:
            if tag not in hashtag_text:
                hashtag_text[tag] = []

            hashtag_text[tag].append(endtag_free_text)

        if include_retweet:
            user_text.append(endtag_free_text)        
        elif not TextProcessingHelpers.find_if_retweet(text):
            user_text.append(endtag_free_text)        

        return end_tags, endtag_free_text    
        
    @staticmethod
    def add_user_feature_count_to_dict(user_dict, user, feature, count):
        try:
            if user not in user_dict:
                user_dict[user] = {}

            user_feature_count =  user_dict[user]

            if feature not in user_feature_count:
                user_feature_count[feature] = int(count)
            else:
                user_feature_count[feature] += int(count)
        except:
            print('error', feature, count)

            
    @staticmethod   
    def add_feature_count_to_dict(feature_dict, feature, count):
        try:
            if feature not in feature_dict:
                feature_dict[feature] = int(count)
            else:
                feature_dict[feature] += int(count)

        except:
            print('error', feature, count)        

    @staticmethod       
    def get_event_data(all_events = ['guncontrol', 'abortion', 'obamacare'],
                       output_path = './results/', 
                       label_folder_path = '',
                       label_file_extension = '',
                      data_folder = '../stance_dataset/biaswatch_data/',
                      use_labeled_users_only = True):



        event_data = {}
        for event in all_events: #['Santa_Fe_Shooting', 'Student_Marches' , 'Iran_Deal']:

            label_file_name = label_folder_path + event + label_file_extension

            folder_path =  data_folder + event + '/'

            # endtags_weighted.csv
            # user,endtag,count
            user_tweet_count = {}
            user_endtag_count = {}
            endtag_count = {}

        #     endtags_data = pd.read_csv(path.join(folder_path, 'endtags_weighted.csv'), dtype={'user':str}, 
        #                                error_bad_lines=False)

            with open(path.join(folder_path, 'endtags_weighted.csv') , 'r') as f_read:
                for line in f_read:
                    parts = line.strip().split(',')

                    if len(parts) ==3:
                        user, endtag, count = parts
                        user = str(user)
                        DataTablesExtractor.add_feature_count_to_dict(endtag_count, endtag, count)
                        DataTablesExtractor.add_feature_count_to_dict(user_tweet_count, user, count)
                        DataTablesExtractor.add_user_feature_count_to_dict(user_endtag_count, user, endtag, count)


            # retweets_weighted.csv    
            # source_tweet_user,retweet_user,count    
            user_retweet_count = {}
        #     data = pd.read_csv(path.join(folder_path, 'retweets_weighted.csv'), dtype={'source_tweet_user':str,
        #                                                                                       'retweet_user': str})

            with open(path.join(folder_path, 'retweets_weighted.csv') , 'r') as f_read:
                for line in f_read:
                    parts = line.strip().split(',')

                    if len(parts) ==3:
                        retweet_user, source_tweet_user, count = parts
                        source_tweet_user = str(source_tweet_user)
                        retweet_user = str(retweet_user)
                        
                        DataTablesExtractor.add_feature_count_to_dict(user_tweet_count, retweet_user, count)    
                        DataTablesExtractor.add_user_feature_count_to_dict(user_retweet_count, retweet_user, source_tweet_user, count)

            # replies_weighted.csv   
            # source_user,reply_user,count 
        #     data = pd.read_csv(path.join(folder_path, 'replies_weighted.csv'), dtype={'source_user':str,
        #                                                                             'reply_user': str})

            user_replies_count = {}    
            with open(path.join(folder_path, 'replies_weighted.csv') , 'r') as f_read:
                for line in f_read:
                    parts = line.strip().split(',')

                    if len(parts) == 3:
                        source_user, reply_user, count = parts   
                        source_user = str(source_user)
                        reply_user = str(reply_user)
                        
                        DataTablesExtractor.add_user_feature_count_to_dict(user_replies_count, reply_user, source_user, count)    

                        DataTablesExtractor.add_feature_count_to_dict(user_tweet_count, source_user, count)    
                        DataTablesExtractor.add_feature_count_to_dict(user_tweet_count, reply_user, count)        

            print('user_tweet_count: ', len(user_tweet_count))    
            print('user_retweet_count:  ', len(user_retweet_count))
            print('user_endtag_count: ', len(user_endtag_count))
            print('endtag_count: ', len(endtag_count))

            print('user_endtag_count examples: ', list(user_endtag_count.keys())[0:20])
            print('user_retweet_count exampless: ', list(user_retweet_count.keys())[0:20])    
            print('user_replies_count exampless: ', list(user_replies_count.keys())[0:20])           

            
            users_text = {}
            endtags_text = {}
            hashtag_text = {}
            
            #  {"user": 26476606, "data": {"Type": "RT", "TweetId": "26476606-ae9c0034-912d-4670-b04a-4c55578c7d32", "Text": "RT @ShaughnA: @DACrosse: How about self control not gun control?!? Excellently said!\n\n#SELFCONTROLNOW"}}
            with open(path.join(folder_path, 'users_text.tsv') , 'r') as f_read:
                for line in f_read:
                    try:
                        
                        parts = json.loads(line.strip())
                        user = str(parts['user'])
                        data = parts['data']
                        text = data['Text']
                        data_type = data['Type']

                        DataTablesExtractor.add_feature_count_to_dict(user_tweet_count, user, 0)    

                        if user not in users_text:
                            users_text[user] = []


                        end_tags, endtag_free_text = DataTablesExtractor.extract_text_hashtags(text, 
                                                                          users_text[user],
                                                                          endtags_text, 
                                                                          hashtag_text)
                    except Exception as ex:
                        print(ex)
                        continue
            
            
            print('users_text: ', len(users_text))
            print('endtags_text: ', len(endtags_text))
            print('hashtag_text: ', len(hashtag_text))
            
                ## now get stance for urls, wbesites
            user_url_count = {}
            with open(path.join(folder_path, 'urls_weighted.csv') , 'r') as f_read:
                for line in f_read:
                    parts = line.strip().split(',')

                    if len(parts) ==3:
                        user, url, count = parts
                        user = str(user)
                        
                        if user in user_tweet_count and 'twitter' not in url.lower(): # lets ignore users that not other interactions
                            DataTablesExtractor.add_user_feature_count_to_dict(user_url_count, user, url, count)
                        

            print('user_url_count: ', len(user_url_count))                    
                        


                ## now get stance for urls, wbesites
            user_media_url_count = {}
            try:
                with open(path.join(folder_path, 'media_fullurls_weighted.csv') , 'r') as f_read:
                    for line in f_read:
                        parts = line.strip().split(',')

                        if len(parts) ==3:
                            user, url, count = parts
                            user = str(user)
                            
                            if user in user_tweet_count: # lets ignore users that not other interactions
                                DataTablesExtractor.add_user_feature_count_to_dict(user_media_url_count, user, url, count)
                            

            except:
                print('media_fullurls_weighted data issue')

            print('user_media_url_count: ', len(user_media_url_count))                    




            # user_replies_count = {}    
            # with open(path.join(folder_path, 'replies_weighted.csv') , 'r') as f_read:
            #     for line in f_read:
            #         parts = line.strip().split(',')

            #         if len(parts) == 3:
            #             source_user, reply_user, count = parts   

            #             add_user_feature_count_to_dict(user_replies_count, reply_user, source_user, count)    

            #             add_feature_count_to_dict(user_tweet_count, source_user, count)    
            #             add_feature_count_to_dict(user_tweet_count, reply_user, count)        


            reply_filter_terms_used_in_orignal_paper = { 'fakenews', 'bullsht', 'bullship', 'false', 'lying', 'fake', 'there is no', 'lie', 'lies', 'wrong', 'there are no', 'untruthful', 'fallacious', 'disinformation', 'made up', 'unfounded', 'insincere',
            'doesnt exist', 'misrepresenting', 'misrepresent', 'unverified', 'not true', 'debunked', 'deceiving', 'deceitful', 'unreliable', 'misinformed', 'doesn’t exist', 'liar', 'unmasked', 'fabricated', 'inaccurate', 'gaslight', 'incorrect', 'misleading', 'deception', 'bogus',
            'gaslighting', 'mistaken', 'mislead', 'phony', 'hoax', 'fiction', 'not exist', 'politifact', 'factcheck', 'opensecrets', 'snopes'}
            USE_SERACH_TERMS_TO_FILTER = False

            reply_data = []
            file_name = ''
            
            if use_labeled_users_only:
                file_name =  'filtered_tweets_conversations_for_labeled_users.tsv'        
            else:
                file_name =  'filtered_tweets_conversations.tsv'
                
                
            with open(path.join(folder_path, file_name), 'r') as f_read: # _for_labeled_users.tsv
                for line in f_read:
                    fields = line.split('\t')
                    if len(fields) == 6:
                        source_tweet_id, sourse_user_id,  source_text, reply_tweet_id, reply_user_id, reply_text = fields
                        
                        to_add = False
                        
                        if len(reply_filter_terms_used_in_orignal_paper) == 0 or not USE_SERACH_TERMS_TO_FILTER:
                            to_add = True
                        else:
                            for term in reply_filter_terms_used_in_orignal_paper:
                                if  term in reply_text.lower(): #term in source_text.lower() or
                                    to_add = True
                                    break
                            
                        if to_add:   
                            reply_data.append((sourse_user_id, source_text, reply_user_id, reply_text))
                                
            print('reply_data count', len(reply_data))

            user_label = DataTablesExtractor.extract_labels(label_file_name)
            event_data[event] = Data(user_tweet_count, user_retweet_count, user_endtag_count, user_replies_count, user_url_count,
                    users_text, endtags_text, hashtag_text, user_label, user_media_url_count, reply_data)
                                            
            
        return event_data
